package com.nsdl.beckn.np.model;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.Where;

import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

import lombok.Data;

@Entity
@Table(name = "np_subscribe_request")
@Data
@Where(clause = "sft_dlt=false")
@SQLDelete(sql = "update np_onboarding_request   set sft_dlt=true where id=?")
public class NPSubscribeRequest extends CommonModel {

	@Column(name = "rq_id")
	String reqId;
	
	@Column(name = "sbscrbr_id")
	String subscriberId;
 	 
	@Column(name = "api_lgs_id", columnDefinition = "char(36)")
	UUID apiLogsId;
		
	@Column(name = "chllng_stts")
	Boolean challangeStatus; 	 
	
	
}
