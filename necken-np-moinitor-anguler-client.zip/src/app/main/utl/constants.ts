export const Constants = {
  Buyer_to_Gateway: "Buyer_to_Gateway",
  Gateway_to_Seller: "Gateway_to_Seller",
  Seller_to_Gateway: "Seller_to_Gateway",
  Gateway_to_Buyer: "Gateway_to_Buyer",
};
