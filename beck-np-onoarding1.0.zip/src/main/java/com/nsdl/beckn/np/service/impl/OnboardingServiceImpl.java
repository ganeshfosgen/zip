package com.nsdl.beckn.np.service.impl;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.nsdl.beckn.np.config.listener.OnSubscribeEvent;
import com.nsdl.beckn.np.config.listener.OnSubscribeEventURL;
import com.nsdl.beckn.np.dao.NPApiLogsRepository;
import com.nsdl.beckn.np.dao.NPMasterRepository;
import com.nsdl.beckn.np.dao.NPOnboardingRequestRepository;
import com.nsdl.beckn.np.dao.NPSubscribeRequestRepository;
import com.nsdl.beckn.np.dao.RegistryRepository;
import com.nsdl.beckn.np.model.NPApiLogs;
import com.nsdl.beckn.np.model.NPMaster;
import com.nsdl.beckn.np.model.NPOnboardingRequest;
import com.nsdl.beckn.np.model.NPSubscribeRequest;
import com.nsdl.beckn.np.model.RegistryEnum;
import com.nsdl.beckn.np.model.RegistryKeys;
import com.nsdl.beckn.np.model.request.ReqDinit;
import com.nsdl.beckn.np.model.request.ReqDverify;
import com.nsdl.beckn.np.model.request.ReqKinit;
import com.nsdl.beckn.np.model.request.ReqLookup;
import com.nsdl.beckn.np.model.request.ReqSubscribe;
import com.nsdl.beckn.np.model.response.MessageErrorResponse;
import com.nsdl.beckn.np.model.response.MessageResponse;
import com.nsdl.beckn.np.model.response.MessageSucessResponse;
import com.nsdl.beckn.np.model.response.MessageSucessSubscribeResponse;
import com.nsdl.beckn.np.model.response.ResponseNPMaster;
import com.nsdl.beckn.np.service.OnboardingService;
import com.nsdl.beckn.np.utl.CommonUtl;
import com.nsdl.beckn.np.utl.Constants;
import com.nsdl.beckn.np.utl.SecurityUtils;
import com.nsdl.signing.crypto.EncryptDecrypt;
import com.nsdl.signing.crypto.GeneratePayload;
import com.nsdl.signing.model.KeyData;
import com.nsdl.signing.model.RequestEncDecryptData;
import com.nsdl.signing.model.Web;
import com.nsdl.signing.service.CryptoService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class OnboardingServiceImpl implements OnboardingService, ApplicationContextAware {

	@Autowired
	SecurityUtils securityUtils;

	@Autowired
	CryptoService cryptoService;

	@Autowired
	NPApiLogsRepository logsRepository;

	@Autowired
	RegistryRepository registryRepository;

	@Autowired
	NPMasterRepository masterRepository;

//	@Autowired
//	RediesCache rediesCache;
	@Autowired
	NPSubscribeRequestRepository subscribeRequestRepository;

	@Autowired
	NPOnboardingRequestRepository onboardingRequestRepository;

	@Autowired
	Gson gson;

	@Autowired
	EncryptDecrypt encryptDecrypt;

	private ApplicationContext applicationContext;

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}

	public NPApiLogs saveLogs(Object req) {
		NPApiLogs logs = new NPApiLogs();
		securityUtils.initCommonProperties(logs);
		logs.setJsonRequest(CommonUtl.convertObjectToMap(req));
		logs.setType(securityUtils.getUserDetails().getLogsType());
		logsRepository.save(logs);
		securityUtils.setLogId(logs.getId());
		return logs;

	}

	public String getDomain(String url) {
		try {
			URL u = new URL(url);
			return u.getProtocol() + "://" + u.getAuthority();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return url;
	}

	public boolean verifyDomain(NPApiLogs log1, String ackCode) {
		boolean verify = false;
		try {

			if (log1.getJsonRequest().get("subscriberUrl") != null) {

				URL u = null;
				try {
					u = new URL((String) log1.getJsonRequest().get("subscriberUrl"));
					log.info("URL : " + u.getProtocol() + "://" + u.getAuthority() + "/ondc-site-verification.html");
					u = new URL(u.getProtocol() + "://" + u.getAuthority() + "/ondc-site-verification.html");

				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					// e1.printStackTrace();
					log.info("ERROR URL " + u.getPath() + " error {} ", e1.getMessage());

					// Log.error(e1.getMessage());
				}
				if (u != null) {
					try (InputStream in = u.openStream()) {
						String data = new String(in.readAllBytes(), StandardCharsets.UTF_8);
						verify = data.indexOf("'" + ackCode + "'") != -1;
					} catch (IOException e) {
						// TODO Auto-generated catch block
						// e.printStackTrace();
						log.error("ERROR URL " + u.getPath() + " error {} ", e.getMessage());

					}
				}
			}

		} catch (Exception e) {
			// e.printStackTrace();
			// TODO: handle exception
			log.error("ERROR URL  error {} ", e.getMessage());

		}
		return verify;
	}

	@Override
	public void saveLogsResponse(ResponseEntity resonse) {
		// TODO Auto-generated method stub
		try {

			NPApiLogs log = logsRepository.getById(securityUtils.getUserDetails().getLogsId());
			if (log != null) {
				log.setJsonResponse(CommonUtl.convertObjectToMap(resonse));
				logsRepository.save(log);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@Override
	public void saveLogsResponseTime(Integer time) {
		// TODO Auto-generated method stub
		try {
			NPApiLogs log = logsRepository.getById(securityUtils.getUserDetails().getLogsId());
			if (log != null) {
				log.setResponseTime(time);
				logsRepository.save(log);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	public MessageResponse validatedSchema(ReqDinit reqDinit) {
		if (reqDinit.getSubscriberId() == null || "".equals(reqDinit.getSubscriberId().trim())) {
			return MessageErrorResponse.errorCommon(Constants.RESPONSE_ONBORDING_REQUEST_SubscriberId_ERROR);
		}
		if (reqDinit.getSubscriberUrl() == null || "".equals(reqDinit.getSubscriberUrl().trim())) {
			return MessageErrorResponse.errorCommon(Constants.RESPONSE_ONBORDING_REQUEST_subscriber_url_ERROR);
		}
		if (reqDinit.getConfReqID() == null || "".equals(reqDinit.getConfReqID().trim())) {
			return MessageErrorResponse.errorCommon(Constants.RESPONSE_ONBORDING_REQUEST_confReqID_ERROR);
		}
		if (reqDinit.getEncrPublicKey() == null || "".equals(reqDinit.getEncrPublicKey().trim())) {
			return MessageErrorResponse.errorCommon(Constants.RESPONSE_ONBORDING_REQUEST_encr_public_key_ERROR);
		}
		if (reqDinit.getSigningPublicKey() == null || "".equals(reqDinit.getSigningPublicKey().trim())) {
			return MessageErrorResponse.errorCommon(Constants.RESPONSE_ONBORDING_REQUEST_signing_public_key_ERROR);
		}
		if (reqDinit.getCallbackUrl() == null || "".equals(reqDinit.getCallbackUrl().trim())) {
			return MessageErrorResponse.errorCommon(Constants.RESPONSE_ONBORDING_REQUEST_callback_url_ERROR);
		}
		String validDate=CommonUtl.checkDate(reqDinit.getValidFrom(), reqDinit.getValidUntil());
		if(validDate!=null) {
			return MessageErrorResponse.errorCommon(new String[] {Constants.RESPONSE_DATE_ERROR[0], validDate});

		}
		return null;
	}

	public MessageResponse validatedVerifySchema(ReqDverify reqDinit) {
		if (reqDinit.getConfReqID() == null || "".equals(reqDinit.getConfReqID().trim())) {
			return MessageErrorResponse.errorCommon(Constants.RESPONSE_ONBORDING_REQUEST_VERIFY_confReqID_ERROR);
		}
		if (reqDinit.getDInitAckCode() == null || "".equals(reqDinit.getDInitAckCode().trim())) {
			return MessageErrorResponse.errorCommon(Constants.RESPONSE_ONBORDING_REQUEST_VERIFY_dInitAckCode_ERROR);
		}
		if (reqDinit.getVerReqID() == null || "".equals(reqDinit.getVerReqID().toString().trim())) {
			return MessageErrorResponse.errorCommon(Constants.RESPONSE_ONBORDING_REQUEST_VERIFY_verReqID_ERROR);
		}

		return null;
	}

	public MessageResponse validatedKINITSchema(ReqKinit reqDinit) {
		if (reqDinit.getKeyVerReqID() == null || "".equals(reqDinit.getKeyVerReqID().trim())) {
			return MessageErrorResponse.errorCommon(Constants.RESPONSE_ONBORDING_REQUEST_KINIT_keyVerReqID_ERROR);
		}
		if (reqDinit.getDVerifyAckCode() == null || "".equals(reqDinit.getDVerifyAckCode().trim())) {
			return MessageErrorResponse.errorCommon(Constants.RESPONSE_ONBORDING_REQUEST_KINIT_dVerifyAckCode_ERROR);
		}
		if (reqDinit.getSignature() == null || "".equals(reqDinit.getSignature().toString().trim())) {
			return MessageErrorResponse.errorCommon(Constants.RESPONSE_ONBORDING_REQUEST_KINIT_signature_ERROR);
		}

		if (reqDinit.getEncMessage() == null || "".equals(reqDinit.getEncMessage().toString().trim())) {
			return MessageErrorResponse.errorCommon(Constants.RESPONSE_ONBORDING_REQUEST_KINIT_encMessage_ERROR);
		}

		return null;
	}

	public MessageResponse validatedOnsubscribeSchema(ReqSubscribe reqDinit) {
		if (reqDinit.getSubscriberId() == null || "".equals(reqDinit.getSubscriberId().trim())) {
			return MessageErrorResponse.errorCommon(Constants.RESPONSE_ONBORDING_REQUEST_SubscriberId_ERROR);
		}

		if (reqDinit.getEncrPublicKey() == null || "".equals(reqDinit.getEncrPublicKey().trim())) {
			return MessageErrorResponse.errorCommon(Constants.RESPONSE_ONBORDING_REQUEST_encr_public_key_ERROR);
		}
		if (reqDinit.getSigningPublicKey() == null || "".equals(reqDinit.getSigningPublicKey().trim())) {
			return MessageErrorResponse.errorCommon(Constants.RESPONSE_ONBORDING_REQUEST_signing_public_key_ERROR);
		}
		if (reqDinit.getReqID() == null || "".equals(reqDinit.getReqID().trim())) {
			return MessageErrorResponse.errorCommon(Constants.RESPONSE_SUBCRIBE_REQUEST_reqID_ERROR);
		}
		if (reqDinit.getPreviousReqId() == null || "".equals(reqDinit.getPreviousReqId().trim())) {
			return MessageErrorResponse.errorCommon(Constants.RESPONSE_SUBCRIBE_REQUEST_previous_req_id_ERROR);
		}
		if (reqDinit.getSignature() == null || "".equals(reqDinit.getSignature().trim())) {
			return MessageErrorResponse.errorCommon(Constants.RESPONSE_SUBCRIBE_REQUEST_signature_ERROR);
		}
		String validDate=CommonUtl.checkDate(reqDinit.getValidFrom(),reqDinit.getValidUntil());
		if(validDate!=null) {
			return MessageErrorResponse.errorCommon(new String[] {Constants.RESPONSE_DATE_ERROR[0], validDate});

		}
		return null;
	}

	@Override
	public MessageResponse verifyDInit(ReqDinit reqDinit) {
		MessageResponse response = null;
		try {

			NPApiLogs logs = saveLogs(reqDinit);
			response = validatedSchema(reqDinit);
			if (response != null)
				return response;
			log.info("Checking OCSP : " + reqDinit.getSubscriberUrl());
			String ocspStatus = cryptoService.checkOCSP(new Web(reqDinit.getSubscriberUrl()));
			log.info("Checking OCSP : " + reqDinit.getSubscriberUrl() + " : " + ocspStatus);
			if (!Constants.OCSP_NOT_VALID.equals(ocspStatus)) {

				NPOnboardingRequest request = null;
				List<NPMaster> master = masterRepository
						.findBySubscriberUrlDomain(getDomain(reqDinit.getSubscriberUrl()));
				String ackCode = null;
				if (master.size() > 0) {
					ackCode = master.get(0).getAckCode();
				} else {
					List<NPOnboardingRequest> ilist = onboardingRequestRepository
							.findBySubscriberUrl((getDomain(reqDinit.getSubscriberUrl())));
					if (ilist.size() > 0) {
						ackCode = ilist.get(0).getDInitAckCode();
					}
				}
				List<NPOnboardingRequest> list = onboardingRequestRepository.findByConfReqId(reqDinit.getConfReqID());

				if (list.size() == 0) {
					request = new NPOnboardingRequest();
					securityUtils.initCommonProperties(request);
					request.setSubscriberId(reqDinit.getSubscriberId());
					request.setDInitAckCode(ackCode == null ? UUID.randomUUID().toString() : ackCode);

					request.setApiLogsId(logs.getId());
					request.setConfReqId(reqDinit.getConfReqID());
					request.setSubscriberUrl(getDomain(reqDinit.getSubscriberUrl()));
					onboardingRequestRepository.save(request);
				} else {
					request = list.get(0);
					securityUtils.initCommonProperties(request);
					request.setDInitAckCode(ackCode == null ? request.getDInitAckCode() : ackCode);
					request.setApiLogsId(logs.getId());
					request.setSubscriberId(reqDinit.getSubscriberId());
					request.setSubscriberUrl(getDomain(reqDinit.getSubscriberUrl()));
					onboardingRequestRepository.save(request);

				}
			//	applicationContext.publishEvent(new OnSubscribeEventURL(this));
		
				response = MessageSucessResponse.ok(request.getDInitAckCode());
			} else {
				response = MessageErrorResponse.errorOCSP();
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			log.info("{} error {} ", "verifyD/Init", e.getMessage());

			response = MessageErrorResponse.errorOCSP();
		}
		return response;
	}

	@Override
	public MessageResponse verifyDVerify(ReqDverify reqDverify) {
		MessageResponse reponse = new MessageResponse();
		String data = null;
		NPMaster master = null;

		boolean verify = false;
		NPApiLogs logs = saveLogs(reqDverify);

		try {

			reponse = validatedVerifySchema(reqDverify);
			if (reponse != null)
				return reponse;

			// get Onboarding object
			List<NPOnboardingRequest> list = onboardingRequestRepository.findByConfReqId(reqDverify.getConfReqID());

			if (list.size() > 0) {
				NPOnboardingRequest onboardingRequest = list.get(0);

				// Get logs Object
				logs = logsRepository.getById(onboardingRequest.getApiLogsId());
				if (logs != null) {

					List<NPMaster> listMaster = masterRepository.findByVerReqId(reqDverify.getVerReqID().toString());
					if (listMaster.size() != 0) {
						master = listMaster.get(0);
					} else {
						master = new NPMaster();
						master.setKeyVerification(UUID.randomUUID().toString());
					}
					securityUtils.initCommonProperties(master);
					if (onboardingRequest.getDInitAckCode().equals(reqDverify.getDInitAckCode()))
						verify = verifyDomain(logs, reqDverify.getDInitAckCode());
					else
						return MessageErrorResponse.errorAckCode();
					master.loadFromLogs(logs, reqDverify, onboardingRequest);
					master.setUnderDomainVerification(verify);
					master.setStatus(Constants.STATUS_SUBSCRIBED);
					masterRepository.save(master);
					applicationContext.publishEvent(new OnSubscribeEventURL(this));
					

				}

			} else {
				return MessageErrorResponse.errorRequestID();
			}
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		if (verify) {
			reponse = MessageSucessResponse.okVerifyDomain(reqDverify.getDInitAckCode(), master.getKeyVerification());
		} else {
			reponse = MessageErrorResponse.errorVerifyDomain(reqDverify.getDInitAckCode());

		}
		return reponse;
	}

	@Override
	public MessageResponse verifyKInit(ReqKinit reqKinit) {
		MessageResponse reponse = new MessageResponse();
		boolean verifySignature = false;
		boolean verifyEncryption = false;
		NPMaster master = null;
		try {
			NPApiLogs logs = saveLogs(reqKinit);

			reponse = validatedKINITSchema(reqKinit);
			if (reponse != null)
				return reponse;

			List<NPMaster> list = masterRepository.findByKeyVerification(reqKinit.getDVerifyAckCode());

			if (list.size() > 0) {
				master = list.get(0);
				log.info("Master : " + master.getId() + " : Sign Public Key (" + master.getSigningPublicKey() + ") : "
						+ " : Signatue (" + reqKinit.getSignature() + ") ");
				String blakeValue = GeneratePayload.generateBlakeHash(master.getKeyVerification());

				verifySignature = GeneratePayload.verifySignaturePK(reqKinit.getSignature(), blakeValue,
						master.getSigningPublicKey());

				List<RegistryKeys> listReg = registryRepository
						.findFirstByTypeOrderByCreatedDateDesc(RegistryEnum.ENCRYPTION);
				if (listReg.size() > 0) {
					RequestEncDecryptData requestEncDecryptData = new RequestEncDecryptData();
					requestEncDecryptData.setValue(reqKinit.getEncMessage());
					requestEncDecryptData.setClientPublicKey(master.getEncrPublicKey());
					requestEncDecryptData.setProteanPrivateKey(listReg.get(0).getPrivateKey());

					log.info("RequestEncDecryptData : (encrypt text )" + reqKinit.getEncMessage()
							+ " : Encrypt Public Key (" + master.getEncrPublicKey() + ") : " + " : Proten Private Key ("
							+ listReg.get(0).getPrivateKey() + ") ");

					String decrStr = encryptDecrypt.decrypt(requestEncDecryptData);
					verifyEncryption = master.getKeyVerification().equals(decrStr);
					log.info("verifyEncryption : " + decrStr + ":" + master.getKeyVerification());
				} else {
					return MessageErrorResponse.errorServerKey();
				}
			} else {
				return MessageErrorResponse.errorSVerifyReqID();
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.info("ERROR RequestEncDecryptData : " + e.getMessage());
			return MessageErrorResponse.error();

		}
		if (verifyEncryption && verifySignature && master != null) {

			reponse = MessageSucessResponse.okVerifyKInit(UUID.randomUUID().toString());
		} else if (!verifySignature) {
			reponse = MessageErrorResponse.errorSVerifyKInit();

		} else {
			reponse = MessageErrorResponse.errorEncrVerifyKInit();

		}
		return reponse;
	}

	@Override
	public Map<String, String> getPublicKey() {
		Map<String, String> map = new HashMap<>();
		System.out.println(RegistryEnum.ENCRYPTION.toString());
		List<RegistryKeys> list = registryRepository.findFirstByTypeOrderByCreatedDateDesc(RegistryEnum.ENCRYPTION);
		map.put("protean_public_key", list.get(0).getPublicKey());
		return map;
	}

	@Override
	public List<ResponseNPMaster> lookup(ReqLookup reqLookup) {
		List<ResponseNPMaster> al = null;//rediesCache.getLookup(reqLookup);
		if (al == null) {

			//applicationContext.publishEvent(new OnSubscribeEventURL(this));
			
			MessageResponse reponse = new MessageResponse();
			NPApiLogs logs = saveLogs(reqLookup);

//		if ((reqLookup.getCity() == null || "".equals(reqLookup.getCity().trim()))
//				&& (reqLookup.getCountry() == null || "".equals(reqLookup.getCountry().trim()))
//				&& (reqLookup.getDomain() == null || "".equals(reqLookup.getDomain().trim()))
//				&& (reqLookup.getType() == null || "".equals(reqLookup.getType().trim()))
//				&& (reqLookup.getSubscriberId() == null || "".equals(reqLookup.getSubscriberId().trim()))) {
//			return MessageErrorResponse.errorLookup();
//		}

			List<NPMaster> list = masterRepository.findAll(new Specification<NPMaster>() {
				@Override
				public Predicate toPredicate(Root<NPMaster> root, CriteriaQuery<?> query,
						CriteriaBuilder criteriaBuilder) {
					List<Predicate> predicates = new ArrayList<>();
					predicates.add(
							criteriaBuilder.and(criteriaBuilder.like(root.get("status"), Constants.STATUS_SUBSCRIBED)));

					if (reqLookup.getCity() != null && !"".equals(reqLookup.getCity().trim())) {
						predicates
								.add(criteriaBuilder.and(criteriaBuilder.like(root.get("city"), reqLookup.getCity())));
					}
					if (reqLookup.getCountry() != null && !"".equals(reqLookup.getCountry().trim())) {
						predicates.add(
								criteriaBuilder.and(criteriaBuilder.like(root.get("country"), reqLookup.getCountry())));
					}
					if (reqLookup.getDomain() != null && !"".equals(reqLookup.getDomain().trim())) {
						predicates.add(
								criteriaBuilder.and(criteriaBuilder.like(root.get("domain"), reqLookup.getDomain())));
					}
					if (reqLookup.getType() != null && !"".equals(reqLookup.getType().trim())) {
						predicates
								.add(criteriaBuilder.and(criteriaBuilder.like(root.get("type"), reqLookup.getType())));
					}
					if (reqLookup.getSubscriberId() != null && !"".equals(reqLookup.getSubscriberId().trim())) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.like(root.get("subscriberId"), reqLookup.getSubscriberId())));
					}

					return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
				}
			});
			List<ResponseNPMaster> alNp = new ArrayList();
			if (list.size() != 0) {
				list.forEach((master) -> alNp.add(new ResponseNPMaster(master)));
			}
			//rediesCache.setLookup(reqLookup, alNp);
			return alNp;// new MessageCustomeResponse<List<ResponseNPMaster>>(al);

		} else {
			return al;
		}
	}

	@Override
	public String initRKey() {
		KeyData key = cryptoService.generateSignKey();
		NPApiLogs logs = saveLogs(new RegistryKeys());
		RegistryKeys rKey = new RegistryKeys();
		securityUtils.initCommonProperties(rKey);
		rKey.setPrivateKey(key.getPrivateKey());
		rKey.setPublicKey(key.getPublicKey());
		rKey.setType(RegistryEnum.SIGNING);
		registryRepository.save(rKey);

		key = cryptoService.generateEncrypDecryptKey();
		rKey = new RegistryKeys();
		securityUtils.initCommonProperties(rKey);
		rKey.setPrivateKey(key.getPrivateKey());
		rKey.setPublicKey(key.getPublicKey());
		rKey.setType(RegistryEnum.ENCRYPTION);
		registryRepository.save(rKey);

		return "ok";
	}

	@Override
	public MessageResponse onSubScribe(ReqSubscribe reqSubscribe) {
		MessageResponse response = null;
		try {

			NPApiLogs logs = saveLogs(reqSubscribe);

			response = validatedOnsubscribeSchema(reqSubscribe);
			if (response != null)
				return response;
//			List<NPOnboardingRequest> list = onboardingRequestRepository
//					.findByConfReqId(reqSubscribe.getPreviousReqId());
//			NPOnboardingRequest request = null;
//			if (list.size() > 0) {

			List<NPMaster> listMaster = masterRepository.findByVerReqId(reqSubscribe.getPreviousReqId());

			if (listMaster.size() > 0) {
				NPMaster master = listMaster.get(0);
				String ocspStatus = cryptoService.checkOCSP(new Web(master.getSubscriberUrl()));

				if (!Constants.OCSP_NOT_VALID.equals(ocspStatus)) {

					if (master.getVerReqId().equals(reqSubscribe.getPreviousReqId())) {
						String blakeValue = GeneratePayload.generateBlakeHash(master.getKeyVerification());

						boolean verifySignature = GeneratePayload.verifySignaturePK(reqSubscribe.getSignature(),
								blakeValue, master.getSigningPublicKey());
						if (verifySignature) {
							NPSubscribeRequest subscribeRequest = null;

							List<NPSubscribeRequest> listSubscribe = subscribeRequestRepository
									.findByReqId(reqSubscribe.getReqID());
							if (listSubscribe.size() == 0) {
								subscribeRequest = new NPSubscribeRequest();
								subscribeRequest.setReqId(reqSubscribe.getReqID());
							} else {
								subscribeRequest = listSubscribe.get(0);
							}
							subscribeRequest.setApiLogsId(logs.getId());
							subscribeRequest.setSubscriberId(reqSubscribe.getSubscriberId());
							subscribeRequest.setChallangeStatus(false);
							securityUtils.initCommonProperties(subscribeRequest);
							subscribeRequestRepository.save(subscribeRequest);
							applicationContext.publishEvent(new OnSubscribeEvent(this, subscribeRequest, master,
									reqSubscribe, securityUtils.getUserId(), securityUtils.getSrcIP()));
							//applicationContext.publishEvent(new OnSubscribeEventURL(this));
							
							return MessageSucessSubscribeResponse.ok();
						
						} else {
							return MessageErrorResponse.errorSVerifyKInit();
						}
					} else {
						return MessageErrorResponse.errorReqID();
					}

				} else {
					return MessageErrorResponse.errorOCSP();
				}
			} else {
				return MessageErrorResponse.errorReqID();
//				return MessageErrorResponse.errorSubscribeID();
			}

			// response = MessageSucessResponse.ok(request.getDInitAckCode());

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			log.info("{} error {} ", "verifyD/Init", e.getMessage());

			response = MessageErrorResponse.error();
		}
		return response;
	}

}
