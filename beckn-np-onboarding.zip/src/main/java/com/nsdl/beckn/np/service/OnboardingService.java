package com.nsdl.beckn.np.service;

import java.util.UUID;

import org.springframework.http.ResponseEntity;

import com.nsdl.beckn.np.model.MessageResponse;
import com.nsdl.beckn.np.model.request.ReqDinit;
import com.nsdl.beckn.np.model.request.ReqDverify;
import com.nsdl.beckn.np.model.request.ReqKinit;
import com.nsdl.beckn.np.model.request.ReqLookup;
import com.nsdl.beckn.np.model.request.ReqSubscribe;

public interface OnboardingService  {
 
	public MessageResponse verifyDInit(ReqDinit reqDinit);
	
	public void saveLogsResponse(ResponseEntity resonse);
	public void saveLogsResponseTime(Integer time);
	public MessageResponse verifyDVerify(ReqDverify reqDinit);
	public MessageResponse verifyKInit(ReqKinit reqKinit);
	public MessageResponse lookup(ReqLookup reqLookup);
	public String initRKey();
	public MessageResponse onSubScribe(ReqSubscribe reqSubscribe);
}
