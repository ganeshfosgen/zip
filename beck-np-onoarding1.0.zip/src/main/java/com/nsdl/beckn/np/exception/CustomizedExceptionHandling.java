package com.nsdl.beckn.np.exception;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.nsdl.beckn.np.model.response.MessageResponse;
import com.nsdl.beckn.np.model.response.Response;
import com.nsdl.beckn.np.service.OnboardingService;

@ControllerAdvice
public class CustomizedExceptionHandling extends ResponseEntityExceptionHandler {

	@Autowired
	OnboardingService onboardingService;
	
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Response<String>> handleExceptions( Exception exception, WebRequest webRequest) {
        //Response<String> response = new Response<String>(Constants.RESPONSE_ERROR,exception.getMessage());
        
        //ResponseEntity<Object> entity = new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);
        return Response.error(exception.getMessage(),onboardingService);
    }
}