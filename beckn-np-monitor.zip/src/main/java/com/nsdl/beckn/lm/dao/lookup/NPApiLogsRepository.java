package com.nsdl.beckn.lm.dao.lookup;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.nsdl.beckn.lm.model.lookup.NPApiLogs;

@Repository
public interface NPApiLogsRepository extends JpaRepository<NPApiLogs, UUID> {
	List<NPApiLogs> findByTypeAndCreatedDateBetweenOrderByCreatedDateAsc(String type, OffsetDateTime start,
			OffsetDateTime end);

	@Query(value = "SELECT lt from NPApiLogs lt ORDER BY createdDate desc ")
	List<NPApiLogs> findLogsBySubscriberId(String subscriberId);

//	@Query(value = "Select to_json(jsn_rqst::TEXT) request, to_json(jsn_rspns::TEXT) response,created_on created from np_api_logs "
//			+ "where jsn_rqst->'message'->'entity'->>'subscriberId' = ?1 "
//			+ "order by created_on desc limit 500", nativeQuery = true)
//	List<ApiLogsProjecttion> findLogsBySubscriberId(String subscriberId);
}
