package com.nsdl.beckn.np.model.request;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class RequestSearch {

	@JsonProperty("sender_subscriber_id")
	String sender_subscriber_id;

	@JsonProperty("request_id")
	String requestId;

	@JsonProperty("timestamp")
	String timestamp;

	@JsonProperty("search_parameters")
	RequestSearchParam searchParameters;

	@JsonProperty("signature")
	String signature;

	@JsonIgnore()
	String statusCode;

	@JsonIgnore()
	String msg;

}
