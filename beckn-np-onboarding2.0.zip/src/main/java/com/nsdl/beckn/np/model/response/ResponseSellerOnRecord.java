package com.nsdl.beckn.np.model.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.nsdl.beckn.np.model.SellerOnRecordMaster;

import lombok.Data;

@Data
public class ResponseSellerOnRecord {

	@JsonProperty("unique_key_id")
	String uniqueKeyId;

	@JsonProperty("key_pair")
	ResponseKeyPair keyPair;

	@JsonProperty("city_code")

	List<String> cityCode;

	public ResponseSellerOnRecord(SellerOnRecordMaster seller) {
		this.uniqueKeyId = seller.getUniqueKeyId();
		this.keyPair = new ResponseKeyPair(seller.getSigningPublicKey(), seller.getEncryptionPublicKey(),
				seller.getValidFrom(), seller.getValidUntil());
		this.cityCode = seller.getCityCode();
	}

}
