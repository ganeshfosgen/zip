package com.nsdl.beckn.lm.config;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;

import com.zaxxer.hikari.HikariDataSource;

@Configuration
@EnableJpaRepositories(basePackages = "com.nsdl.beckn.lm.dao.transaction", entityManagerFactoryRef = "transactionEntityManagerFactory", transactionManagerRef = "transactionTransactionManager")
public class TransactionDataSourceConfiguration {

	@Value("spring.jpa.hibernate.ddl-auto")
	String ddlAuto;

	@Value("spring.jpa.show-sql")
	String showSql;

	@Value("spring.jpa.properties.hibernate.format_sql")
	String formatSql;

	@Value("spring.jpa.properties.hibernate.connection.isolation")
	String connectIsolation;

	@Value("logging.level.org.hibernate.type")
	String logType;

	@Bean
	@ConfigurationProperties("spring.datasource.transaction")
	public DataSourceProperties transactionDataSourceProperties() {
		return new DataSourceProperties();
	}

	@Bean
	@ConfigurationProperties("spring.datasource.transaction.configuration")
	public DataSource transactionDataSource() {
		return transactionDataSourceProperties().initializeDataSourceBuilder().type(HikariDataSource.class).build();
	}

	@Bean(name = "transactionEntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean transactionEntityManagerFactory(EntityManagerFactoryBuilder builder) {
		Map<String, Object> properties = new HashMap<>();
		properties.put("spring.jpa.hibernate.ddl-auto", this.ddlAuto);
		properties.put("spring.jpa.show-sql", this.showSql);
		properties.put("spring.jpa.properties.hibernate.format_sql", this.formatSql);
		properties.put("logging.level.org.hibernate.type", this.logType);
		properties.put("spring.jpa.properties.hibernate.connection.isolation", this.connectIsolation);

		return builder.dataSource(transactionDataSource()).packages("com.nsdl.beckn.lm.model.transaction")
				.properties(properties).build();
	}

	@Bean
	public PlatformTransactionManager transactionTransactionManager(
			final @Qualifier("transactionEntityManagerFactory") LocalContainerEntityManagerFactoryBean transactionEntityManagerFactory) {
		return new JpaTransactionManager(transactionEntityManagerFactory.getObject());
	}

}