package com.nsdl.beckn.np.exception;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.nsdl.beckn.np.model.response.Response;
import com.nsdl.beckn.np.service.OnboardingSubscirberService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ControllerAdvice
public class CustomizedExceptionHandling extends ResponseEntityExceptionHandler {

	@Autowired
	OnboardingSubscirberService onboardingService;

	@ExceptionHandler(Exception.class)
	public ResponseEntity<Response<String>> handleExceptions(Exception exception, WebRequest webRequest) {
		// Response<String> response = new
		// Response<String>(Constants.RESPONSE_ERROR,exception.getMessage());
		try {

			exception.printStackTrace();
			log.info(exception.getMessage());
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		// ResponseEntity<Object> entity = new
		// ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);
		return Response.error(exception.getMessage(), this.onboardingService);
	}
}