import { Component, OnInit, ViewChild, ViewEncapsulation } from "@angular/core";

import { locale as en } from "../i18n/en";
import { locale as fr } from "../i18n/fr";
import { locale as de } from "../i18n/de";
import { locale as pt } from "../i18n/pt";

import { CoreTranslationService } from "@core/services/translation.service";
import {
  NgbCalendar,
  NgbDate,
  NgbDateParserFormatter,
} from "@ng-bootstrap/ng-bootstrap";
import { FlatpickrOptions } from "ng2-flatpickr";
import { FormBuilder, FormGroup } from "@angular/forms";
import { ColumnMode, id } from "@swimlane/ngx-datatable";
import { HttpCommonService } from "../../service/http.common.servce";
import { ApiAuditLogsService } from "../../service/api.audit.logs.servce";
import { Constants } from "../../utl/constants";
import { ToastrService } from "ngx-toastr";
import { reduce } from "rxjs/operators";

@Component({
  selector: "app-transaction",
  templateUrl: "./transaction.component.html",
  styleUrls: ["./transaction.component.scss"],
  encapsulation: ViewEncapsulation.None,
})
export class TransactionComponent implements OnInit {
  public DateRangeOptions: FlatpickrOptions = {
    altInput: true,
    mode: "range",
    altFormat: "j-m-Y",
  };

  onGetRowClass = (row) => {
    if (row.flag) {
      return "color-transaction-row-red";
    } else {
      return "color-transaction-row-green";
    }
  };

  // onGetRowClass(row): string {
  //   if(row.flag){
  //     return "color-transaction-row-red";
  //   }else{
  //     return "color-transaction-row-green";
  //   }

  // }
  public selectBasic = [{ id: 1, name: "abc" }];
  public selectBasicLoading = false;

  public DefaultDateOptions: FlatpickrOptions = {
    defaultDate: "2019-03-19",
    altInput: true,
  };
  _DefaultDateSnippetCode = {};
  form: FormGroup;
  DAY = 86400000;
  @ViewChild("tableRowDetails_buyer_to_Gateway")
  tableRowDetails_buyer_to_Gateway: any;
  //rows=[];

  @ViewChild("tableRowDetails_Gateway_to_Seller")
  tableRowDetails_Gateway_to_Seller: any;

  @ViewChild("tableRowDetails_SellerToGateway")
  tableRowDetails_SellerToGateway: any;
  @ViewChild("tableRowDetails_GatewayToBuyer")
  tableRowDetails_GatewayToBuyer: any;

  Constants: any;
  rowsBuyerToGateway = [];
  rowsGatewayToSeller = [];
  rowsSellerToGateway = [];
  rowsrowsGatewayToBuyer = [];

  selectIds = [];
  tempData = [];
  searchFlag = false;

  map: Map<string, Array<Map<string, any>>>;
  public ColumnMode = ColumnMode;
  error: boolean;
  /**
   *
   * @param {CoreTranslationService} _coreTranslationService
   */
  constructor(
    private _coreTranslationService: CoreTranslationService,
    private calendar: NgbCalendar,
    public formatter: NgbDateParserFormatter,
    private formBuilder: FormBuilder,
    private apiAuditLogsService: ApiAuditLogsService,
    private toastr: ToastrService
  ) {
    this.Constants = Constants;
    this._coreTranslationService.translate(en, fr, de, pt);
    // this.fromDate = calendar.getToday();
    // this.toDate = calendar.getNext(calendar.getToday(), 'd', 10);
    this.form = formBuilder.group({
      transactionId: "",
      date: "",
      selectTranscationId: "",
    });
  }

  rowDetailsToggleExpand(row, table) {
    table.rowDetail.toggleExpandRow(row);
  }

  filterUpdate(event, key) {
    const val = event.target.value.toLowerCase();

    let tempData: Array<Map<string, any>> = this.map[key];

    // filter our data
    const temp = tempData.filter((d: any) => {
      let flag = !val;
      //console.log(d.toString());
      if (!flag) {
        Object.keys(d).forEach((item) => {
          try {
            flag = flag || d[item].toLowerCase().indexOf(val) !== -1;
          } catch (error) {}
        });
      }
      return flag;
    });

    // update the rows
    if (key == Constants.Buyer_to_Gateway) {
      this.rowsBuyerToGateway = temp;
      this.tableRowDetails_buyer_to_Gateway.offset = 0;
    } else if (key == Constants.Gateway_to_Seller) {
      this.rowsGatewayToSeller = temp;
      this.tableRowDetails_Gateway_to_Seller.offset = 0;
    } else if (key == Constants.Seller_to_Gateway) {
      this.rowsSellerToGateway = temp;
      this.tableRowDetails_SellerToGateway.offset = 0;
    } else if (key == Constants.Gateway_to_Buyer) {
      this.rowsrowsGatewayToBuyer = temp;
      this.tableRowDetails_GatewayToBuyer.offset = 0;
    }
    // Whenever the filter changes, always go back to the first page
  }

  initRows() {
    this.rowsBuyerToGateway = [];
    this.rowsGatewayToSeller = [];
    this.rowsSellerToGateway = [];
    this.rowsrowsGatewayToBuyer = [];
  }

  loadRows(item) {
    this.map = item;
    let rowsBuyerToGateway = this.map[Constants.Buyer_to_Gateway];
    let rowsGatewayToSeller = this.map[Constants.Gateway_to_Seller];
    let rowsSellerToGateway = this.map[Constants.Seller_to_Gateway];
    let rowsrowsGatewayToBuyer = this.map[Constants.Gateway_to_Buyer];

    for (var element of rowsBuyerToGateway) {
      console.log(element);
      if (
        element["Gatway_Status"] &&
        element["Gatway_Status"].indexOf("ERROR") != -1
      ) {
        element["flag"] = true;
      } else if (
        element["Buyer_status"] &&
        element["Buyer_status"].indexOf("ERROR") != -1
      ) {
        element["flag"] = true;
      } else {
        element["flag"] = false;
      }
    }

    for (var element of rowsGatewayToSeller) {
      console.log(element);
      if (
        element["Gatway_Status"] &&
        element["Gatway_Status"].indexOf("ERROR") != -1
      ) {
        element["flag"] = true;
      } else if (
        element["Seller_Status"] &&
        element["Seller_Status"].indexOf("ERROR") != -1
      ) {
        element["flag"] = true;
      } else {
        element["flag"] = false;
      }
    }

    for (var element of rowsSellerToGateway) {
      console.log(element);
      if (
        element["Gatway_Status"] &&
        element["Gatway_Status"].indexOf("ERROR") != -1
      ) {
        element["flag"] = true;
      } else if (
        element["Seller_Status"] &&
        element["Seller_Status"].indexOf("ERROR") != -1
      ) {
        element["flag"] = true;
      } else {
        element["flag"] = false;
      }
    }

    for (var element of rowsrowsGatewayToBuyer) {
      console.log(element);

      if (
        element["Gatway_Status"] &&
        element["Gatway_Status"].indexOf("ERROR") != -1
      ) {
        element["flag"] = true;
      } else if (
        element["Seller_Status"] &&
        element["Seller_Status"].indexOf("ERROR") != -1
      ) {
        element["flag"] = true;
      } else {
        element["flag"] = false;
      }
    }

    // if (rowsBuyerToGateway.length > 0) {
    //   rowsBuyerToGateway.forEach((item) => {
    //     this.rowsBuyerToGateway.push(item);
    //   });
    // }
    // if (rowsGatewayToSeller.length > 0) {
    //   rowsGatewayToSeller.forEach((item) => {
    //     this.rowsGatewayToSeller.push(item);
    //   });
    // }
    // if (rowsSellerToGateway.length > 0) {
    //   rowsSellerToGateway.forEach((item) => {
    //     this.rowsSellerToGateway.push(item);
    //   });
    // }
    // if (rowsrowsGatewayToBuyer.length > 0) {
    //   rowsrowsGatewayToBuyer.forEach((item) => {
    //     this.rowsrowsGatewayToBuyer.push(item);
    //   });
    // }
    this.rowsBuyerToGateway=[...this.rowsBuyerToGateway, ...rowsBuyerToGateway];
    this.rowsGatewayToSeller=[...this.rowsGatewayToSeller, ...rowsGatewayToSeller];
    this.rowsSellerToGateway=[...this.rowsSellerToGateway,...rowsSellerToGateway];
    this.rowsrowsGatewayToBuyer=[...this.rowsrowsGatewayToBuyer,...rowsrowsGatewayToBuyer];
    let val =
      this.rowsBuyerToGateway.length +
      this.rowsGatewayToSeller.length +
      this.rowsSellerToGateway.length +
      this.rowsrowsGatewayToBuyer.length;
    if (val == 0) {
      this.toastr.error("Transaction Id is not found.", "Error!", {
        toastClass: "toast ngx-toastr",
        closeButton: true,
        progressBar: true,
      });
    }
     
    return rowsBuyerToGateway.length +
    rowsGatewayToSeller.length +
    rowsSellerToGateway.length +
    rowsrowsGatewayToBuyer.length;
  }
  searchTransactionWithId(value) {
    this.searchFlag = true;
    this.initRows();
   
    this.apiAuditLogsService.getByTansationId(value).subscribe((item) => {
      this.loadRows(item);

      this.searchFlag = false;
    });
  }

  searchTransactionWithDateRange(start, end,page) {
    if(page==1)
    this.initRows();

    if(page==1)
    this.searchFlag = true;
    
    this.apiAuditLogsService.getByAuditbyDate(start, end,page).subscribe((item) => {
     // this.loadRows(item);
      this.searchFlag = false;
     
      if( this.loadRows(item)==0)
      console.log("Received");

      else{
        this.searchTransactionWithDateRange(start,end,page+1)
      }
    });
  }
  searchTransaction() {
    let value = this.form.controls.transactionId.value;
    if (!value || value.trim() == "") {
      this.toastr.error("Please enter Transaction Id.", "Error!", {
        toastClass: "toast ngx-toastr",
        closeButton: true,
        progressBar: true,
      });
    } else {
      this.searchTransactionWithId(value);
    }
  }

  searchTransactionDateRange() {
    let date = this.form.controls.date.value;

    if (!date || date.length < 2) {
      this.toastr.error("Please select proper date range.", "Error!", {
        toastClass: "toast ngx-toastr",
        closeButton: true,
        progressBar: true,
      });
    } else {
      console.log(this.apiAuditLogsService.getFormatDate(date[0]));
      console.log(this.apiAuditLogsService.getFormatDate(date[1]));
      this.searchTransactionWithDateRange(
        this.apiAuditLogsService.getFormatDate(date[0]),
        this.apiAuditLogsService.getFormatDate(date[1]),1
      );
      //this.searchTransactionWithId(value);
    }
  }
  searchSelectTransaction() {
    let value = this.form.controls.selectTranscationId.value;
    if (!value || !value.id || value.id.trim() == "") {
      this.toastr.error("Please enter Transaction Id.", "Error!", {
        toastClass: "toast ngx-toastr",
        closeButton: true,
        progressBar: true,
      });
    } else {
      this.searchTransactionWithId(value.id);
    }
  }

  /**
   * On init
   */
  ngOnInit() {
    this.selectBasicLoading = true;
    this.apiAuditLogsService.getAllTransaction().subscribe((item) => {
      this.selectIds = [];
      if (item) {
        item.forEach((id) => {
          this.selectIds.push({ id: id, name: id });
        });
      }
      this.selectBasicLoading = false;
    });
  }
}
function str(str: any) {
  throw new Error("Function not implemented.");
}

function forrowsBuyerToGateway() {
  throw new Error("Function not implemented.");
}

// function getRowClass(row: any) {
//   throw new Error("Function not implemented.");
// }

function row(row: any) {
  throw new Error("Function not implemented.");
}
