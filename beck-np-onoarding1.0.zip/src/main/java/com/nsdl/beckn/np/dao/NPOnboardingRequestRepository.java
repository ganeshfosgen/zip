package com.nsdl.beckn.np.dao;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nsdl.beckn.np.model.NPOnboardingRequest;
 
 
@Repository
public interface NPOnboardingRequestRepository extends JpaRepository<NPOnboardingRequest, UUID>{
	  List<NPOnboardingRequest> findByConfReqId(String confReqId);
	  List<NPOnboardingRequest> findBySubscriberId(String subscriberId);
	  List<NPOnboardingRequest> findBySubscriberUrl(String subscriberUrl);
	  
}
