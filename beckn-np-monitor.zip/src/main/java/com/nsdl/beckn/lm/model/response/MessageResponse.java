package com.nsdl.beckn.lm.model.response;

import lombok.Data;

@Data
public class MessageResponse {

	
	
	
}