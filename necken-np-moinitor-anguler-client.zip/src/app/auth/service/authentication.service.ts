import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { BehaviorSubject, Observable } from "rxjs";
import { map } from "rxjs/operators";

import { environment } from "environments/environment";
import { User, Role } from "app/auth/models";
import { ToastrService } from "ngx-toastr";
import { AuthConfig, OAuthService } from "angular-oauth2-oidc";
import { debug } from "console";
import { BreakPointRegistry } from "@angular/flex-layout";
@Injectable({ providedIn: "root" })
export class AuthenticationService {
  // public
  public currentUser: Observable<User>;
  public currentKeycloakUser: any;
  // private
  private currentUserSubject: BehaviorSubject<User>;
  public loginFlag = false;
  authConfig: AuthConfig = {
    issuer: environment.urlOauth2,
    redirectUri: environment.webApiRedirectURL,
    clientId: environment.clientId,
    scope: environment.scope,
    responseType: "code",
    requireHttps: false,
    // at_hash is not present in id token in older versions of keycloak.
    // use the following property only if needed!
    // disableAtHashCheck: true,
    showDebugInformation: true,
  };

  /**
   *
   * @param {HttpClient} _http
   * @param {ToastrService} _toastrService
   */
  constructor(
    private _http: HttpClient,
    private _toastrService: ToastrService,
    private oauthService: OAuthService
  ) {
    this.currentUserSubject = new BehaviorSubject<User>(
      JSON.parse(localStorage.getItem("currentUser"))
    );
    this.currentUser = this.currentUserSubject.asObservable();
  }

  // getter: currentUserValue
  public get currentUserValue(): User {
    return this.currentUserSubject.value;
  }

  /**
   *  Confirms if user is admin
   */
  get isAdmin() {
    return (
      this.currentUser && this.currentUserSubject.value.role === Role.Admin
    );
  }

  /**
   *  Confirms if user is client
   */
  get isClient() {
    return (
      this.currentUser && this.currentUserSubject.value.role === Role.Client
    );
  }

  /**
   * User login
   *
   * @param email
   * @param password
   * @returns user
   */
  login(email: string, password: string) {
    return this._http
      .post<any>(`${environment.apiUrl}/users/authenticate`, {
        email,
        password,
      })
      .pipe(
        map((user) => {
          // login successful if there's a jwt token in the response
          if (user && user.token) {
            // store user details and jwt token in local storage to keep user logged in between page refreshes
            localStorage.setItem("currentUser", JSON.stringify(user));

            // Display welcome toast!
            setTimeout(() => {
              this._toastrService.success(
                "You have successfully logged in as an " +
                  user.role +
                  " user to Vuexy. Now you can start to explore. Enjoy! 🎉",
                "👋 Welcome, " + user.firstName + "!",
                { toastClass: "toast ngx-toastr", closeButton: true }
              );
            }, 2500);

            // notify
            this.currentUserSubject.next(user);
          }

          return user;
        })
      );
  }

  /**
   * User logout
   *
   */
  logout() {
    // remove user from local storage to log user out
    localStorage.removeItem("currentUser");
    // notify

    this.logoff();
    this.currentUserSubject.next(null);
    this.loginFlag = false;

    // this.oauthService.loadDiscoveryDocumentAndTryLogin();
  }

  public loginKeyClock() {
    this.oauthService.initLoginFlow();
  }

  public logoff() {
    this.oauthService.revokeTokenAndLogout();
    //this.oauthService.logOut();
    window.sessionStorage.clear();
    setTimeout(()=>{
      this.loginRedirect(0);
    },1000)
    
  }

  public isLogin() {
    if (this.oauthService.getIdentityClaims()) {
      this.loginFlag = true;

      this.currentKeycloakUser = this.oauthService.getIdentityClaims();
      // console.log(item);

      //});
    } else {
      this.loginFlag = false;
    }
    return this.oauthService.getAccessToken() != undefined;
  }

  getUserNameShort() {
    return this.currentKeycloakUser &&
      this.currentKeycloakUser["preferred_username"]
      ? this.currentKeycloakUser["preferred_username"].substr(0, 1)
      : "";
  }
  public getUserName() {
    return this.currentKeycloakUser
      ? this.currentKeycloakUser["preferred_username"]
      : "";
  }

  loginRedirect(cnt) {
    this.loginFlag = this.isLogin();
    // debugger;
    console.log("wait for login: "+cnt);
    
    if(!window.sessionStorage.getItem("refresh_token")){
      this.oauthService.initLoginFlow();
      
    }
    if (!this.loginFlag && cnt == 10) {
      this.oauthService.initLoginFlow();
      return;
    }
    if (this.loginFlag) {
      return;
    } else {
      cnt++;
    }
    if (cnt <= 10) {
      setTimeout(() => {
        this.loginRedirect(cnt);
      }, 1000);
    }
  }

  public configure() {
    var cnt = 0;

    this.oauthService.configure(this.authConfig);
    this.oauthService.setupAutomaticSilentRefresh();

    this.oauthService.loadDiscoveryDocumentAndTryLogin().then((response) => {
       this.loginRedirect(0);
    });
  }
}
