package com.nsdl.beckn.np;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.nsdl.beckn.np.controller.OnboardingSubcriberController;

@SpringBootTest
public class SmokeTest {

	@Autowired
	private OnboardingSubcriberController controller;

	@Test
	public void contextLoads() throws Exception {
		assertThat(this.controller).isNotNull();
	}
}
