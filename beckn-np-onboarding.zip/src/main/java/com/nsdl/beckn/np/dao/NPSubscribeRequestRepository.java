package com.nsdl.beckn.np.dao;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nsdl.beckn.np.model.NPOnboardingRequest;
import com.nsdl.beckn.np.model.NPSubscribeRequest;
 
 
@Repository
public interface NPSubscribeRequestRepository extends JpaRepository<NPSubscribeRequest, UUID>{
	  List<NPSubscribeRequest> findByReqId(String reqId);
}
