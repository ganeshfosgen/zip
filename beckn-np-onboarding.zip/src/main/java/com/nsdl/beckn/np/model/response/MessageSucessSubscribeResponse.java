package com.nsdl.beckn.np.model.response;

import com.nsdl.beckn.np.utl.Constants;

import lombok.Data;

@Data
public class MessageSucessSubscribeResponse extends MessageResponse {

	String status;
 

	public static MessageResponse ok( ) {
		MessageSucessSubscribeResponse response = new MessageSucessSubscribeResponse();
	 	
		response.status = Constants.RESPONSE_ONSUBSCRIBE_OK[1];
		return response;
	}
	
 
}