package com.nsdl.beckn.np.utl;

import java.util.Map;

import com.google.gson.Gson;

public class CommonUtl {

	public static Map<String, Object> convertObjectToMap(Object obj) {
		Gson gson = new Gson();
		return gson.fromJson(gson.toJson(obj), Map.class);
		
	}
	
	
}
