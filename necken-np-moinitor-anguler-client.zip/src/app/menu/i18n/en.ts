export const locale = {
  lang: 'en',
  data: {
    MENU: {
      HOME: "Dashboard",
      TRANSACTION: "Transactions",
      SUMMARY_REPORT:"Summary Report",
      SELLER_TRANSACTION:"Seller transaction",
      BUYER_TRANSACTION:"Buyer transaction",
      LOOKUP:"Lookup Transaction"
    }
  }
}
