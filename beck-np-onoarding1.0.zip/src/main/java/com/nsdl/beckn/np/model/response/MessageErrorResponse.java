package com.nsdl.beckn.np.model.response;

import com.nsdl.beckn.np.service.impl.OnboardingServiceImpl;
import com.nsdl.beckn.np.utl.Constants;

import lombok.Data;
import lombok.extern.log4j.Log4j;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class MessageErrorResponse extends MessageResponse {
	String errCode;
	String details;
	public static MessageResponse errorOCSP() {
		MessageErrorResponse response = new MessageErrorResponse();
		response.errCode = Constants.RESPONSE_ONBORDING_REQUEST_OCSP_ERROR[0];
		response.details = Constants.RESPONSE_ONBORDING_REQUEST_OCSP_ERROR[1];
		log.info("ERROR : {} ",response);
		return response;
	}
	
	public static MessageResponse errorCommon(String []error) {
		MessageErrorResponse response = new MessageErrorResponse();
		response.errCode = error[0];
		response.details = error[1];
		log.info("ERROR : {} ",response);
		return response;
	}
	
	public static MessageResponse errorReqID() {
		MessageErrorResponse response = new MessageErrorResponse();
		response.errCode = Constants.RESPONSE_ONSUBSCRIBE_REQUEST_ERROR[0];
		response.details = Constants.RESPONSE_ONSUBSCRIBE_REQUEST_ERROR[1];
		log.info("ERROR : {} ",response);
		return response;
	}
	
	public static MessageResponse errorSubscribeID() {
		MessageErrorResponse response = new MessageErrorResponse();
		response.errCode = Constants.RESPONSE_ONSUBSCRIBE_SUBSCRIBE_ID_ERROR[0];
		response.details = Constants.RESPONSE_ONSUBSCRIBE_SUBSCRIBE_ID_ERROR[1];
		log.info("ERROR : {} ",response);
		return response;
	}
	
	public static MessageResponse errorSVerifyReqID() {
		MessageErrorResponse response = new MessageErrorResponse();
		 
		response.errCode = Constants.RESPONSE_VERIFYK_REQ_ID_INIT_ERROR[0];
		response.details = Constants.RESPONSE_VERIFYK_REQ_ID_INIT_ERROR[1];
		log.info("ERROR : {} ",response);
		return response;
	}
	public static MessageResponse errorServerKey() {
		MessageErrorResponse response = new MessageErrorResponse();
		 
		response.errCode = Constants.RESPONSE_SERVER_ENC_ERROR[0];
		response.details = Constants.RESPONSE_SERVER_ENC_ERROR[1];
		log.info("ERROR : {} ",response);
		return response;
	}
	public static MessageResponse errorSVerifyKInit() {
		MessageErrorResponse response = new MessageErrorResponse();
		 
		response.errCode = Constants.RESPONSE_VERIFYK_SIG_INIT_ERROR[0];
		response.details = Constants.RESPONSE_VERIFYK_SIG_INIT_ERROR[1];
		log.info("ERROR : {} ",response);
		return response;
	}
	
	public static MessageResponse error() {
		MessageErrorResponse response = new MessageErrorResponse();
		response.errCode = Constants.RESPONSE_ONBORDING_REQUEST_ERROR[0];
		response.details = Constants.RESPONSE_ONBORDING_REQUEST_ERROR[1];
		log.info("ERROR : {} ",response);
		return response;
	}

	public static MessageResponse errorVerifyDomain(String ackCode) {
		MessageErrorResponse response = new MessageErrorResponse();
		response.errCode = Constants.RESPONSE_VERIFY_DOMAIN_ERROR[0];
		response.details = Constants.RESPONSE_VERIFY_DOMAIN_ERROR[1];
		log.info("ERROR : {} ",response);
		return response;
	}
	
	public static MessageResponse errorAckCode() {
		MessageErrorResponse response = new MessageErrorResponse();
		response.errCode = Constants.RESPONSE_VERIFY_ACK_ERROR[0];
		response.details = Constants.RESPONSE_VERIFY_ACK_ERROR[1];
		log.info("ERROR : {} ",response);
		return response;
	}
	public static MessageResponse errorRequestID() {
		MessageErrorResponse response = new MessageErrorResponse();
		response.errCode = Constants.RESPONSE_REQUEST_ID_ERROR[0];
		response.details = Constants.RESPONSE_REQUEST_ID_ERROR[1];
		log.info("ERROR : {} ",response);
		return response;
	}
	
	public static MessageResponse errorEncrVerifyKInit() {
		MessageErrorResponse response = new MessageErrorResponse();
		 
		response.errCode = Constants.RESPONSE_VERIFYK_ENCRYPT_INIT_ERROR[0];
		response.details = Constants.RESPONSE_VERIFYK_ENCRYPT_INIT_ERROR[1];
		log.info("ERROR : {} ",response);
		return response;
	}
	
	public static MessageResponse errorLookup() {
		MessageErrorResponse response = new MessageErrorResponse();
		 
		response.errCode = Constants.RESPONSE_LOOKP_ERROR[0];
		response.details = Constants.RESPONSE_LOOKP_ERROR[1];
		log.info("ERROR : {} ",response);
		return response;
	}

}
