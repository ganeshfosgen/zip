package com.nsdl.beckn.np.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nsdl.beckn.np.config.listener.OnSubscribeEventURL;
import com.nsdl.beckn.np.model.request.ReqDinit;
import com.nsdl.beckn.np.model.request.ReqDverify;
import com.nsdl.beckn.np.model.request.ReqKinit;
import com.nsdl.beckn.np.model.request.ReqLookup;
import com.nsdl.beckn.np.model.request.ReqSubscribe;
import com.nsdl.beckn.np.model.response.MessageResponse;
import com.nsdl.beckn.np.model.response.Response;
import com.nsdl.beckn.np.model.response.ResponseNPMaster;
import com.nsdl.beckn.np.service.OnboardingService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class OnboardingController {
	@Autowired
	OnboardingService onboardingService;
 

	 
	@PostMapping("/verifyParticipant/verifyD/init")
	public ResponseEntity<Response<MessageResponse>> verifyDInit(@RequestBody ReqDinit reqDinit) {
		return Response.ok(onboardingService.verifyDInit(reqDinit),onboardingService);
	}
	
	@PostMapping("/verifyParticipant/verifyD/verify")
	public ResponseEntity<Response<MessageResponse>> verifyDVerify(@RequestBody ReqDverify reqDverify) {
		return Response.ok(onboardingService.verifyDVerify(reqDverify),onboardingService);
	}
	
	@PostMapping("/verifyParticipant/verifyK/init")
	public ResponseEntity<Response<MessageResponse>> verifyKInit(@RequestBody ReqKinit reqKinit) {
		return Response.ok(onboardingService.verifyKInit(reqKinit),onboardingService);
	}
	
	@PostMapping("/subscribe")
	public ResponseEntity<Response<MessageResponse>> subscribe(@RequestBody ReqSubscribe reqSubscribe) {
		return Response.ok(onboardingService.onSubScribe(reqSubscribe),onboardingService);
	}
	
	@PostMapping("/lookup")
	public ResponseEntity<List<ResponseNPMaster>> lookup(@RequestBody ReqLookup reqLookup) {
	 
		return ResponseEntity.ok(onboardingService.lookup(reqLookup));
		
	}
//	@PostMapping("/lookup")
//	public ResponseEntity<List<ResponseNPMaster>> lookupOndc(@RequestBody ReqLookup reqLookup) {
//		return ResponseEntity.ok(onboardingService.lookup(reqLookup));
//	}
	
	@PostMapping("/public/keys")
	public ResponseEntity<Map<String,String>> lookupOndcPublicKey() {
		return ResponseEntity.ok(onboardingService.getPublicKey());
	}
	
	@PostMapping("/generate/registry/key")
	public ResponseEntity<Response<String>> generateKey() {
		return Response.ok(onboardingService.initRKey() ,onboardingService);
	}

}
