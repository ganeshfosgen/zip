package com.nsdl.beckn.np.utl;

import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Map;

import com.google.gson.Gson;

public class CommonUtl {
	public static String parseDomainNamefromUrl(String url) {
//	    if (url == null) return null;
//	    URL rawUrl = null;
//	    try {
//	        rawUrl = new URL(url);
//	    } catch (MalformedURLException e) {
//	        System.out.println("ERROR - failed to create URL from url=" + url);
//	        System.out.println(e.getMessage());
//	        e.printStackTrace();
//	        return url;
//	    }
//	    String host = rawUrl.getHost();
//	    InternetDomainName idn = InternetDomainName.from(host);
//	    while (idn.isTopPrivateDomain() == false && (idn.hasParent()) ) {
//	        idn = idn.parent();
//	    }
//	    String domain = idn.toString();
//	    if (idn.isUnderPublicSuffix()) {
//	        domain =idn.topPrivateDomain().toString();
//	    }
//	    System.out.println("Parsed domain: " + domain);
//	    return domain;
		try {

			URL aURL = new URL(url);
		return aURL.getAuthority();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return "";

	}

	public static String checkDate(String start,String end) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'" );
	//formatter.parse(start).get();
		LocalDateTime st;
		try {
			st=LocalDateTime.parse(start,formatter);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return "Start Date is Invalid date time format.";
		}
				
		LocalDateTime ed;
		try {
			ed=LocalDateTime.parse(end,formatter);
		} catch (Exception e) {
			// TODO: handle exception
			return "End Date is Invalid date time format.";
		}
		if(st.isBefore(ed)) {
			return null;
		}else {
			return "Start Date should be less than end date.";
		}
	}
	public static Map<String, Object> convertObjectToMap(Object obj) {
		Gson gson = new Gson();
		return gson.fromJson(gson.toJson(obj), Map.class);

	}

	public static void main(String[] args) {
	System.out.println( new CommonUtl().checkDate("2022-08-20T01:47:01.001Z", "2022-06-20T01:47:01.001Z"));
	}
	
}
