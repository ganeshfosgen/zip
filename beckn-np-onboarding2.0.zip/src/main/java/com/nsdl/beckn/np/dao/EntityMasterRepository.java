
package com.nsdl.beckn.np.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.nsdl.beckn.np.model.EntityMaster;

@Repository
public interface EntityMasterRepository extends JpaRepository<EntityMaster, String>, JpaSpecificationExecutor {
	List<EntityMaster> findBySubscriberId(String subscriberId);

//	@Query(value = "SELECT e.subscriber_id, cast(m.city_code as varchar) AS city_code,  e.signing_public_key , e.encryption_public_key, "
//			+ "   e.valid_from, e.valid_until,  e.created_on,  e.updated_on, m.type , m.domain, m.msn "
//			+ "   FROM entity_master e , network_participant_master m where" + "	e.subscriber_id = m.subscriber_id "
//			+ "	and e.status='SUBSCRIBED' and m.domain=?1  "
//			+ "	and( m.type=?2) and m.status='SUBSCRIBED'", nativeQuery = true)
//	@Query(value = " SELECT e.subscriber_id SubscriberId,e.country Country,cast(m.city_code as varchar) AS City,  e.signing_public_key SigningPublicKey,"
//			+ " e.encryption_public_key EncryptionPublicKey,  "
//			+ "   e.valid_from ValidFrom, e.valid_until ValidUntil,  e.created_on Created,  e.updated_on Updated, m.type Type,"
//			+ "  m.domain Domain, m.msn Msn,m.subscriber_url SubscriberUrl ,m.callback_url CallbackUrl ,m.id Id "
//			+ "   FROM entity_master e , network_participant_master m where " + "	e.subscriber_id = m.subscriber_id  "
//			+ "	and e.status='SUBSCRIBED' and (?1 ='' or m.domain=?1)  "
//			+ "	and (?2 = '' or m.type=?2) and m.status='SUBSCRIBED' and "
//			+ "  (?3 = '' or e.subscriber_id=?3) and (?4 = '' or e.country=?4)", nativeQuery = true)
//	List<EntityMasterLookupProjection> lookupEntity(String domain, String type, String subscriberId, String country);

}
