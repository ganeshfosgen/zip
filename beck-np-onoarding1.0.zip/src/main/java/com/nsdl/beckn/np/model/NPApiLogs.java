package com.nsdl.beckn.np.model;

import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.Where;

import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

import lombok.Data;

@Entity
@Table(name = "np_api_logs")
@Data
@Where(clause = "sft_dlt=false")
@SQLDelete(sql = "update np_api_logs  set sft_dlt=true where id=?")
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
public class NPApiLogs extends CommonModel {

	@Type(type = "jsonb")
	@Column(name = "jsn_rqst",columnDefinition = "jsonb")
	Map<String,Object> jsonRequest;
	
	@Type(type = "jsonb")
	@Column(name = "jsn_rspns",columnDefinition = "jsonb")
	Map<String,Object>  jsonResponse;
	
	@Column(name = "typ")
	String type;
	
	@Column(name = "rspns_tm")
	Integer responseTime;
	
	 
}
