package com.nsdl.beckn.np;

import com.nsdl.beckn.np.utl.CommonUtl;

public class domain {
public static void main(String[] args) {
	System.out.println( CommonUtl.parseDomainNamefromUrl("https://fossgentechnologies.com/career/"));
	System.out.println( CommonUtl.parseDomainNamefromUrl("https://www.fossgentechnologies.com/career/"));
	System.out.println( CommonUtl.parseDomainNamefromUrl("https://app.fossgentechnologies.com/career/"));
	System.out.println( CommonUtl.parseDomainNamefromUrl("https://www.aap.fossgentechnologies.com/career/"));
	System.out.println( CommonUtl.parseDomainNamefromUrl("http://fossgentechnologies.com/career/"));
	System.out.println( CommonUtl.parseDomainNamefromUrl("http://www.fossgentechnologies.com/career/"));
	System.out.println( CommonUtl.parseDomainNamefromUrl("https://fossgentechnologies.com/career/"));
	
}
}
