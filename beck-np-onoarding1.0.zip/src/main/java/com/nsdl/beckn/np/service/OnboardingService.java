package com.nsdl.beckn.np.service;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;

import com.nsdl.beckn.np.model.request.ReqDinit;
import com.nsdl.beckn.np.model.request.ReqDverify;
import com.nsdl.beckn.np.model.request.ReqKinit;
import com.nsdl.beckn.np.model.request.ReqLookup;
import com.nsdl.beckn.np.model.request.ReqSubscribe;
import com.nsdl.beckn.np.model.response.MessageResponse;
import com.nsdl.beckn.np.model.response.ResponseNPMaster;

public interface OnboardingService  {
 
	public MessageResponse verifyDInit(ReqDinit reqDinit);
	
	public void saveLogsResponse(ResponseEntity resonse);
	public void saveLogsResponseTime(Integer time);
	public MessageResponse verifyDVerify(ReqDverify reqDinit);
	public MessageResponse verifyKInit(ReqKinit reqKinit);
	public Map<String,String> getPublicKey();
	public List<ResponseNPMaster> lookup(ReqLookup reqLookup);
	public String initRKey();
	public MessageResponse onSubScribe(ReqSubscribe reqSubscribe);
}
