package com.nsdl.beckn.np.model.response;

import org.springframework.http.ResponseEntity;

import com.nsdl.beckn.np.service.OnboardingSubscirberService;
import com.nsdl.beckn.np.utl.Constants;

import lombok.Data;

@Data
public class Response<T> {

	public Response(String status, T message) {
		super();
		this.status = status;
		this.message = message;

	}

	private String status;
	private T message;
//
//	public static <T> ResponseEntity<Response<T>> ok(T message, OnboardingSubscirberService onboardingService) {
//		if (message instanceof MessageErrorResponse) {
//			return error(message, onboardingService);
//		} else {
//			ResponseEntity res = ResponseEntity.ok(new Response<T>(Constants.RESPONSE_OK, message));
//			try {
//				onboardingService.saveLogsResponse(res);
//			} catch (Exception e) {
//				// TODO: handle exception
//				System.out.println("Try catch Exception");
//				e.printStackTrace();
//
//			}
//			return res;
//		}
//
//	}

	public static <T> ResponseEntity<T> ok(T message, OnboardingSubscirberService onboardingService) {
//		if (message instanceof MessageErrorResponse) {
//			return error(message, onboardingService);
//		} else {
			ResponseEntity res = ResponseEntity.ok( message);
			try {
				onboardingService.saveLogsResponse(res);
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println("Try catch Exception");
				e.printStackTrace();

			}
			return res;
//		}

	}

	//
	public static <T> ResponseEntity<Response<T>> error(T message, OnboardingSubscirberService onboardingService) {
		ResponseEntity res = ResponseEntity.ok(new Response<T>(Constants.RESPONSE_ERROR, message));
		try {

			onboardingService.saveLogsResponse(res);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Try catch Exception");
			e.printStackTrace();

		}
		return res;
	}

}