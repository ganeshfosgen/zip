package com.nsdl.beckn.lm.service;

import java.util.List;
import java.util.Map;

import com.nsdl.beckn.lm.model.FileBo;
import com.nsdl.beckn.lm.model.Graph;
import com.nsdl.beckn.lm.model.projection.ApiAuditEntityBuyerProjection;
import com.nsdl.beckn.lm.model.projection.ApiAuditEntitySellerProjection;
import com.nsdl.beckn.lm.model.request.LogsRequest;
import com.nsdl.beckn.lm.model.response.LogsResponse;

public interface ApiAuditService {

	Map<String, List<Map<String, Object>>> findTransactionById(String id);

	Map<String, List<Map<String, Object>>> findTransactionByDate(String start, String end, Integer page);

	List<String> getDistinctId();

	List<Graph<Integer>> getDashBoard(String type);

	List<Graph<Integer>> getDashBoard(String select, String type, String start, String end);

	List<Map<String, Object>> findByBuyerSellerTransactionByDate(String type, String start, String end);

	List<Graph<Integer>> getDashBoardLookup(String select, String type, String start, String end);

	FileBo summaryReportExportToExcel(String start, String end);

	List<Graph<Integer>> getDashBoardBuyerId(String select, String type, String start, String end);

	List<ApiAuditEntityBuyerProjection> getDashBoardBuyerAllList(String start, String end);

	List<Graph<Integer>> getDashBoardSellerId(String select, String type, String start, String end);

	List<ApiAuditEntitySellerProjection> getDashBoardSellerAllList(String start, String end);

	List<LogsResponse> findLogsBySubscriberId(LogsRequest body);
}
