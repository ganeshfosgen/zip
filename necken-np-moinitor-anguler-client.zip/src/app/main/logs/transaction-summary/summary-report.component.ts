import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { CoreTranslationService } from "@core/services/translation.service";
import {
  NgbCalendar,
  NgbDateParserFormatter,
} from "@ng-bootstrap/ng-bootstrap";
import { ApiAuditLogsService } from "app/main/service/api.audit.logs.servce";
import { Constants } from "app/main/utl/constants";
import { FlatpickrOptions } from "ng2-flatpickr";
import { ToastrService } from "ngx-toastr";
import { ViewEncapsulation } from "@angular/core";
import { ColumnMode } from "@swimlane/ngx-datatable";
import { HttpClientModule } from "@angular/common/http";
import { FileRespons } from "../../model/response.model";
import { locale as en } from "../i18n/en";
import { locale as fr } from "../i18n/fr";
import { locale as de } from "../i18n/de";
import { locale as pt } from "../i18n/pt";
@Component({
  selector: "app-summary-report",
  templateUrl: "./summary-report.component.html",
  styleUrls: ["./summary-report.component.scss"],
})
export class SummaryReportComponent implements OnInit {
  public DateRangeOptions: FlatpickrOptions = {
    altInput: true,
    mode: "single",
    altFormat: "j-m-Y",
  };
  _DefaultDateSnippetCode = {};
  form: FormGroup;
  DAY = 86400000;
  searchFlag = false;
  map: Map<string, Array<Map<string, any>>>;
  public ColumnMode = ColumnMode;

  
  /**
   *
   * @param {CoreTranslationService} _coreTranslationService
   */
  constructor(
    private _coreTranslationService: CoreTranslationService,
    private calendar: NgbCalendar,
    public formatter: NgbDateParserFormatter,
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private apiAuditLogsService: ApiAuditLogsService
  ) {
    this._coreTranslationService.translate(en, fr, de, pt);
    this.form = formBuilder.group({
      date: "",
    });
  }
   
  searchTransactionDateRange() {
    let date = this.form.controls.date.value;
    if (!date || date.length < 1) {
      this.toastr.error("Please select proper date.", "Error!", {
        toastClass: "toast ngx-toastr",
        closeButton: true,
        progressBar: true,
      });
    } else {
      this.searchFlag=true;
      console.log(this.apiAuditLogsService.getFormatDate(date[0]));
     // console.log(this.apiAuditLogsService.getFormatDate(date[1]));
      this.apiAuditLogsService
        .downloadFileSerivce(
          this.apiAuditLogsService.getFormatDate(date[0]),
          this.apiAuditLogsService.getFormatDate(date[0])
        )
        .subscribe((item: FileRespons) => {
          this.searchFlag=false;
          this.apiAuditLogsService.downloadFile(item);
        });
      //this.searchTransactionWithId(value);
    }
  }

  ngOnInit(): void {}
}
