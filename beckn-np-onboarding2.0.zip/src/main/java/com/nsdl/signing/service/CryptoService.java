package com.nsdl.signing.service;

import java.util.Map;

import com.nsdl.signing.model.KeyData;
import com.nsdl.signing.model.RequestData;
import com.nsdl.signing.model.RequestEncDecryptData;
import com.nsdl.signing.model.Web;

public interface CryptoService {

	String generateSignature(RequestData request);

	String verifySignature(RequestData request);

	String verifySignaturePlan(RequestData request);

	String encryptText(RequestEncDecryptData request);

	String decryptText(RequestEncDecryptData request);

	KeyData generateSignKey();

	KeyData generateEncrypDecryptKey();

	String checkOCSP(Web domain, Map<String, String> error);

	String generateSignaturePlan(RequestData request);

}
