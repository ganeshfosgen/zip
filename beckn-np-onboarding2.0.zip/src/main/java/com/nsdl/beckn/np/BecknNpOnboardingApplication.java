package com.nsdl.beckn.np;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.nsdl.beckn.np.interceptor.ServiceInterceptor;

@SpringBootApplication
@ComponentScan({"com.nsdl.beckn.np","com.nsdl.signing"})
public class BecknNpOnboardingApplication implements WebMvcConfigurer {

	@Autowired(required = true)
	ServiceInterceptor interceptor;
	
    @Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(interceptor);
	}
    
   
	public static void main(String[] args) {
		SpringApplication.run(BecknNpOnboardingApplication.class, args);
	}
	
}