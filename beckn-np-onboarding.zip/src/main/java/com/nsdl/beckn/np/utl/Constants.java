package com.nsdl.beckn.np.utl;

import lombok.Data;

public class Constants {

	public static Integer API_VERSION = 1;
	public static String RESPONSE_ERROR = "error";
	public static String RESPONSE_OK = "success";
	public static String OCSP_NOT_VALID = "Not Valid";

	
	public static String[] RESPONSE_ONBORDING_REQUEST_ERROR = new String[] { "103","Server Side Error. Call Helpdesk for details." };

	public static String[] RESPONSE_ONBORDING_REQUEST_OCSP_ERROR = new String[] { "102","OCSP Validation Failed" };
	public static String[] RESPONSE_ONBORDING_REQUEST_OK = new String[] { "200" ,"Success" };

	public static String[] RESPONSE_VERIFY_DOMAIN_ERROR = new String[] { "101","Domain verification is failed" };
	public static String[] RESPONSE_VERIFY_DOMAIN_OK = new String[] { "200","Domain Verified. Please save ackCode(DverifyAckCode) for verification of keys" };

	public static String[] RESPONSE_VERIFYK_SIG_INIT_ERROR = new String[] { "101","Signature verification is failed" };
	public static String[] RESPONSE_VERIFYK_ENCRYPT_INIT_ERROR = new String[] { "102","Encryption verification is failed" };

	
	public static String[] RESPONSE_ONSUBSCRIBE_REQUEST_ERROR = new String[] { "103","previous_req_id is incorrect" };
	public static String[] RESPONSE_ONSUBSCRIBE_SUBSCRIBE_ID_ERROR = new String[] { "104","subscriber_id is incorrect" };

}
