package com.nsdl.beckn.np.config.listener;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.nsdl.beckn.np.dao.NPMasterRepository;
import com.nsdl.beckn.np.dao.NPSubscribeRequestRepository;
import com.nsdl.beckn.np.dao.RegistryRepository;
import com.nsdl.beckn.np.model.RegistryEnum;
import com.nsdl.beckn.np.model.RegistryKeys;
import com.nsdl.beckn.np.model.request.ReqOnSubsribe;
import com.nsdl.beckn.np.model.request.ResponseOnSubsribe;
import com.nsdl.beckn.np.utl.SecurityUtils;
import com.nsdl.signing.crypto.SubscribeEncryptDecrypt;

import lombok.extern.slf4j.Slf4j;

@Component
@EnableAsync
@Slf4j
public class SpringApplicationEventListener {

	@Value("${cache.reload.url}")
	String cacheReloadUrl;

	@Autowired
	RegistryRepository registryRepository;
	@Autowired
	NPSubscribeRequestRepository subscribeRequestRepository;

	@Autowired
	NPMasterRepository masterRepository;

	@Autowired
	SecurityUtils securityUtils;
	@Autowired
	Gson gson;

//	private ApplicationContext applicationContext;
//
//	@Override
//	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
//		this.applicationContext = applicationContext;
//	}

	@Async
	@EventListener
	public void onSubscribeEven(OnSubscribeEvent subscription) {
		CloseableHttpClient httpClient = HttpClients.createDefault();

		try {
			String url = subscription.master.getCallBackUrl();

			HttpPost request = new HttpPost(url + "/on_subscribe");
			ReqOnSubsribe sub = new ReqOnSubsribe();
			SubscribeEncryptDecrypt encr = new SubscribeEncryptDecrypt();

			List<RegistryKeys> listReg = registryRepository
					.findFirstByTypeOrderByCreatedDateDesc(RegistryEnum.ENCRYPTION);
			sub.setSubscriberId(subscription.master.getSubscriberId());

			String str = UUID.randomUUID().toString();
			sub.setChallenge(encr.encrypt(subscription.master.getEncrPublicKey(), listReg.get(0).getPrivateKey(), str));

			String json = gson.toJson(sub);
			StringEntity entity = new StringEntity(json);
			request.setEntity(entity);
			request.setHeader("Accept", "application/json");
			request.setHeader("Content-type", "application/json");

			CloseableHttpResponse response = httpClient.execute(request);

			try {

				System.out.println(response.getStatusLine().getStatusCode()); // 200

				if (response.getStatusLine().getStatusCode() == 200) {

					String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);

					ResponseOnSubsribe responseSubscribe = gson.fromJson(responseBody, ResponseOnSubsribe.class);
					if (str.equals(responseSubscribe.getAnswer())) {
						subscription.subscription.setChallangeStatus(true);

						subscribeRequestRepository.save(subscription.subscription);
						subscription.master.setCountry(subscription.reqSubscribe.getCountry());
						subscription.master.setCity(subscription.reqSubscribe.getCity());
						subscription.master.setDomain(subscription.reqSubscribe.getDomain());
						subscription.master.setSigningPublicKey(subscription.reqSubscribe.getSigningPublicKey());

						subscription.master.setEncrPublicKey(subscription.reqSubscribe.getEncrPublicKey());
						subscription.master.setValidFrom(subscription.reqSubscribe.getValidFrom());
						subscription.master.setValidUntil(subscription.reqSubscribe.getValidUntil());
						subscription.master.setVerReqId(subscription.reqSubscribe.getReqID());
						securityUtils.initCommonPropertiesWithId(subscription.master, subscription.id, subscription.ip);
						masterRepository.save(subscription.master);
						this.caheRefresh(this.cacheReloadUrl);
						// applicationContext.publishEvent(new OnSubscribeEventURL(this));

					}

				}

			} finally {
				response.close();
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				httpClient.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Async
	@EventListener
	public void onSubscribeEventurl(OnSubscribeEventURL subscription) {
		this.caheRefresh(this.cacheReloadUrl);
	}

	public void caheRefresh(String cacheReloadUrl) {
		CloseableHttpClient httpClient = HttpClients.createDefault();

		try {

			if (cacheReloadUrl.indexOf("cache-reload") != -1) {
				HttpGet request = new HttpGet( cacheReloadUrl);

				CloseableHttpResponse response = httpClient.execute(request);

				System.out.println(response.getStatusLine().getStatusCode()); // 200

				if (response.getStatusLine().getStatusCode() == 200) {
					log.info("caheRefresh", cacheReloadUrl + ":ok");
					// body.getMsgError().put("caheRefresh", cacheReloadUrl + ":ok");
				} else {

					log.info("caheRefresh", cacheReloadUrl + ":ERROR:" + response.getStatusLine().getStatusCode()
							+ response.getStatusLine().toString());
//				body.getMsgError().put("caheRefresh", cacheReloadUrl + ":ERROR:"
//						+ response.getStatusLine().getStatusCode() + response.getStatusLine().toString());
				}
			} else {

				HttpPost request = new HttpPost(cacheReloadUrl);

				String json = " { \"key\": \"beckn-api-cache-lookup\" }";
				StringEntity entity = new StringEntity(json);
				request.setEntity(entity);
				request.setHeader("Accept", "application/json");
				request.setHeader("Content-type", "application/json");

				CloseableHttpResponse response = httpClient.execute(request);

				System.out.println(response.getStatusLine().getStatusCode()); // 200

				if (response.getStatusLine().getStatusCode() == 200) {
					log.info("caheRefresh", cacheReloadUrl + ":ok");
					// body.getMsgError().put("caheRefresh", cacheReloadUrl + ":ok");
				} else {

					log.info("caheRefresh", cacheReloadUrl + ":ERROR:" + response.getStatusLine().getStatusCode()
							+ response.getStatusLine().toString());
//				body.getMsgError().put("caheRefresh", cacheReloadUrl + ":ERROR:"
//						+ response.getStatusLine().getStatusCode() + response.getStatusLine().toString());
				}

			}
		} catch (Exception e) {
			// TODO: handle exception
			log.info("caheRefresh_exception", cacheReloadUrl + ":" + e.getMessage());

//			body.getMsgError().put("caheRefresh_exception", cacheReloadUrl + ":" + e.getMessage());

			e.printStackTrace();
		} finally {
			try {
				httpClient.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
	 
 

}
