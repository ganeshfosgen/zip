package com.nsdl.beckn.np.dao;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nsdl.beckn.np.model.NPMaster;
 
 
@Repository
public interface NPMasterRepository extends JpaRepository<NPMaster, UUID>{
	  List<NPMaster> findBySubscriberId(String subscriberId);
	  List<NPMaster> findByKeyVerification(String keyVerification);
	  
}
