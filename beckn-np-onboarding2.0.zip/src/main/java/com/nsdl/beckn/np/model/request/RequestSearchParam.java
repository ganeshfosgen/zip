package com.nsdl.beckn.np.model.request;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class RequestSearchParam {
	@JsonProperty("city")
	private String city = null;

	@JsonProperty("country")
	private String country = null;

	@JsonProperty("domain")
	private String domain = null;

	@JsonProperty("type")
	private String type = null;

	@JsonProperty("subscriber_id")
	String subscriberId;

	@JsonIgnore()
	String data;

}
