package com.nsdl.beckn.np.config.listener;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;
 
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.nsdl.beckn.np.dao.NPMasterRepository;
import com.nsdl.beckn.np.dao.NPSubscribeRequestRepository;
import com.nsdl.beckn.np.dao.RegistryRepository;
import com.nsdl.beckn.np.model.RegistryEnum;
import com.nsdl.beckn.np.model.RegistryKeys;
import com.nsdl.beckn.np.model.request.ReqOnSubsribe;
import com.nsdl.beckn.np.model.request.ResponseOnSubsribe;
import com.nsdl.beckn.np.utl.SecurityUtils;
import com.nsdl.signing.crypto.SubscribeEncryptDecrypt;

@Component
@EnableAsync
public class SpringApplicationEventListener {

	@Autowired
	RegistryRepository registryRepository;
	@Autowired
	NPSubscribeRequestRepository subscribeRequestRepository;

	@Autowired
	NPMasterRepository masterRepository;

	@Autowired
	SecurityUtils securityUtils;
	@Autowired
	Gson gson;

	@Async
	@EventListener
	public void onSubscribeEven(OnSubscribeEvent subscription) {
		CloseableHttpClient httpClient = HttpClients.createDefault();

		try {
			String url = subscription.master.getCallBackUrl();

			HttpPost request = new HttpPost(url);
			ReqOnSubsribe sub = new ReqOnSubsribe();
			SubscribeEncryptDecrypt encr = new SubscribeEncryptDecrypt();

			List<RegistryKeys> listReg = registryRepository.findAllByType(RegistryEnum.ENCRYPTION);
			sub.setSubscriberId(subscription.master.getSubscriberId());

			String str = UUID.randomUUID().toString();
			sub.setChallenge(encr.encrypt(subscription.master.getEncrPublicKey(), listReg.get(0).getPrivateKey(), str));

			String json = gson.toJson(sub);
			StringEntity entity = new StringEntity(json);
			request.setEntity(entity);
			request.setHeader("Accept", "application/json");
			request.setHeader("Content-type", "application/json");

			CloseableHttpResponse response = httpClient.execute(request);

			try {

				System.out.println(response.getStatusLine().getStatusCode()); // 200

				if (response.getStatusLine().getStatusCode() == 200) {
					 
					String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);

 
					ResponseOnSubsribe responseSubscribe = gson.fromJson(responseBody, ResponseOnSubsribe.class);
					if (str.equals(responseSubscribe.getAnswer())) {
						subscription.subscription.setChallangeStatus(true);

						subscribeRequestRepository.save(subscription.subscription);
						subscription.master.setCountry(subscription.reqSubscribe.getCountry());
						subscription.master.setCity(subscription.reqSubscribe.getCity());
						subscription.master.setDomain(subscription.reqSubscribe.getDomain());
						subscription.master.setSigningPublicKey(subscription.reqSubscribe.getSigningPublicKey());

						subscription.master.setEncrPublicKey(subscription.reqSubscribe.getEncrPublicKey());
						subscription.master.setValidFrom(subscription.reqSubscribe.getValidFrom());
						subscription.master.setValidUntil(subscription.reqSubscribe.getValidUntil());
						securityUtils.initCommonPropertiesWithId(subscription.master, subscription.id, subscription.ip);
						masterRepository.save(subscription.master);

					}
				}

			} finally {
				response.close();
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				httpClient.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
