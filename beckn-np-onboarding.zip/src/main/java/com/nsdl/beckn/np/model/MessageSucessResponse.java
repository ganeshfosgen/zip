package com.nsdl.beckn.np.model;

import com.nsdl.beckn.np.utl.Constants;

import lombok.Data;

@Data
public class MessageSucessResponse extends MessageResponse {

	String ackCode;
	 
	

	public static MessageResponse ok(String ackCode) {
		MessageSucessResponse response = new MessageSucessResponse();
		response.ackCode = ackCode;
		
		response.details = Constants.RESPONSE_ONBORDING_REQUEST_OK[1];
		return response;
	}
	
		public static MessageResponse okVerifyDomain(String ackCode,String verificationCode) {
			MessageSucessResponse response = new MessageSucessResponse();
		response.ackCode = ackCode;
	 	response.details = Constants.RESPONSE_VERIFY_DOMAIN_OK[1].replaceAll("DverifyAckCode", verificationCode);
		return response;
	}
	
	
	
	public static MessageResponse okVerifyKInit(String ackCode) {
		MessageSucessResponse response = new MessageSucessResponse();
		response.ackCode = ackCode;
		response.details="";
//		response.errCode = Constants.RESPONSE_VERIFY_DOMAIN_OK[0];
//		response.details = Constants.RESPONSE_VERIFY_DOMAIN_OK[1].replaceAll("DverifyAckCode", verificationCode);
		return response;
	}
	
	 
	public static MessageSucessResponse okVerifyKInit(String ackCode,String verificationCode) {
		MessageSucessResponse response = new MessageSucessResponse();
		response.ackCode = ackCode;
//		response.errCode = Constants.RESPONSE_VERIFY_DOMAIN_OK[0];
//		response.details = Constants.RESPONSE_VERIFY_DOMAIN_OK[1].replaceAll("DverifyAckCode", verificationCode);
		return response;
	}
	
}