package com.nsdl.beckn.np.service;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;

import com.nsdl.beckn.np.model.request.ErrorResponse;
import com.nsdl.beckn.np.model.request.RequestOldSearch;
import com.nsdl.beckn.np.model.request.RequestSearch;
import com.nsdl.beckn.np.model.request.RequestText;
import com.nsdl.beckn.np.model.request.SubscribeBody;
import com.nsdl.beckn.np.model.response.ResponsEntityMaster;
import com.nsdl.beckn.np.model.response.ResponsOldEntityMaster;
import com.nsdl.beckn.np.model.response.ResponseText;

public interface OnboardingSubscirberService {
	void saveLogsResponseTime(Integer time);

	void saveLogsResponse(ResponseEntity resonse);

	ErrorResponse onSubscribe(SubscribeBody reqSubscribe);

	Map<String, String> getPublicKey();

	String initRKey();

	List<ResponsEntityMaster> lookup(RequestSearch reqLookup);

	boolean checkAuthorization(String authorization, String data, String subscriberId);

	ResponseText getEncryptText(RequestText req);

	ResponseText decryptText(RequestText req);

	void caheRefresh(String url);

	List<ResponsOldEntityMaster> lookupOld(RequestOldSearch request);
}
