package com.nsdl.beckn.lm.model.response;

import java.util.Map;

import com.nsdl.beckn.lm.model.lookup.NPApiLogs;
import com.nsdl.beckn.lm.utl.CommonUtl;

import lombok.Data;

@Data
public class LogsResponse {

	Map<String, Object> request;
	Map<String, Object> response;
	String createdOn;

	public LogsResponse(NPApiLogs obj) {
		this.request = obj.getJsonRequest();
		this.response = obj.getJsonResponse();

		this.createdOn = CommonUtl.convertDatetoString(obj.getCreatedDate());
	}

}
