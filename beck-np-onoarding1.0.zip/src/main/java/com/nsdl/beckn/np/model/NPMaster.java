package com.nsdl.beckn.np.model;

import java.time.OffsetDateTime;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.Where;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.nsdl.beckn.np.model.request.ReqDverify;
import com.nsdl.beckn.np.utl.Constants;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

import lombok.Data;

@Entity
@Table(name = "np_master")
@Data
@Where(clause = "sft_dlt=false")
@SQLDelete(sql = "update np_master  set sft_dlt=true where id=?")
public class NPMaster extends CommonModel {

	@Column(name = "sbscrbr_id")
	String subscriberId;
	
	@Column(name = "sbscrbr_url")
	private String subscriberUrl = null;
	
	@Column(name = "sbscrbr_url_dmn")
	private String subscriberUrlDomain = null;
	
	@Column(name = "undr_dmn_vrfctn")
	Boolean underDomainVerification;
	
	@Column(name = "ocsp_vldtn")
	Boolean ocspValidation;
	
	@Column(name = "vrfy_ack_cd")
	String verifyAckCode;
	
	@Column(name = "ack_cd")
	String ackCode;
	
	@Column(name = "dvrfctn_ack_cd")
	String dverificationAckCode;
	
	@Column(name = "ver_rq_id")
	String verReqId;
	
	@Column(name = "sgnng_pblc_ky")
	String signingPublicKey;
	
	@Column(name = "encr_publc_ky")
	String encrPublicKey;

	@Column(name = "cntry")
	String country; 

	@Column(name = "cty")
	String city; 
	
	@Column(name = "dmn")
	String domain; 
	
	@Column(name = "typ")
	String type; 
	
	@Column(name = "cll_bck_url")
	String callBackUrl;
	
	@Column(name = "ky_vrfctn")
	String keyVerification; 


	@JsonProperty("valid_from")
	private String validFrom = null;

	@JsonProperty("valid_until")
	private String validUntil = null;
	
	@Column(name = "stts", columnDefinition = " varchar(255) default 'SUBSCRIBED'")
	String status;
	
	public void loadFromLogs(NPApiLogs logs,ReqDverify reqDverify,NPOnboardingRequest onboardingRequest) {
		if(logs.getJsonRequest().get("subscriberId")!=null) {
			this.subscriberId=logs.getJsonRequest().get("subscriberId").toString();
		}
		this.ocspValidation=true;
		this.verifyAckCode=reqDverify.getVerReqID().toString();
		this.ackCode=onboardingRequest.dInitAckCode;
		this.dverificationAckCode=reqDverify.getDInitAckCode();
		this.verReqId=reqDverify.getVerReqID().toString();
		this.subscriberUrlDomain=onboardingRequest.getSubscriberUrl();
		
		if(logs.getJsonRequest().get("signingPublicKey")!=null) {
			this.signingPublicKey=logs.getJsonRequest().get("signingPublicKey").toString();
		}
		if(logs.getJsonRequest().get("encrPublicKey")!=null) {
			this.encrPublicKey=logs.getJsonRequest().get("encrPublicKey").toString();
		}
		if(logs.getJsonRequest().get("callbackUrl")!=null) {
			this.callBackUrl=logs.getJsonRequest().get("callbackUrl").toString();
		}
		 
		if(logs.getJsonRequest().get("city")!=null) {
			this.city=logs.getJsonRequest().get("city").toString();
		}
		if(logs.getJsonRequest().get("type")!=null) {
			this.type=logs.getJsonRequest().get("type").toString();
		}
		if(logs.getJsonRequest().get("domain")!=null) {
			this.domain=logs.getJsonRequest().get("domain").toString();
		}
		if(logs.getJsonRequest().get("country")!=null) {
			this.country=logs.getJsonRequest().get("country").toString();
		}
		if(logs.getJsonRequest().get("subscriberUrl")!=null) {
			this.subscriberUrl=logs.getJsonRequest().get("subscriberUrl").toString();
		}
		if(logs.getJsonRequest().get("validFrom")!=null) {
			this.validFrom=logs.getJsonRequest().get("validFrom").toString();
		}
		if(logs.getJsonRequest().get("validUntil")!=null) {
			this.validUntil=logs.getJsonRequest().get("validUntil").toString();
		}
	}
}
