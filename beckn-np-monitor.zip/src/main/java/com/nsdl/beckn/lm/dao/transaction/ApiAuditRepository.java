package com.nsdl.beckn.lm.dao.transaction;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.nsdl.beckn.lm.model.projection.ApiAuditEntityBuyerProjection;
import com.nsdl.beckn.lm.model.projection.ApiAuditEntityProjecttion;
import com.nsdl.beckn.lm.model.projection.ApiAuditEntitySellerProjection;
import com.nsdl.beckn.lm.model.transaction.ApiAuditEntity;

@Repository
public interface ApiAuditRepository extends JpaRepository<ApiAuditEntity, String> {
	List<ApiAuditEntity> findByTransactionIdOrderByCreatedOnAsc(String transactionId);
	List<ApiAuditEntity> findByCreatedOnBetweenOrderByCreatedOnAsc(LocalDateTime start,LocalDateTime end);

	List<ApiAuditEntity> findByCreatedOnBetweenOrderByCreatedOnAsc(LocalDateTime start,LocalDateTime end,Pageable pageable);
	@Query("select transactionId from ApiAuditEntity apiAuditEntity where apiAuditEntity.createdOn between ?1 and ?2 ")
	List<String> findDistinctTransactionIdByCreatedOnBetween(LocalDateTime start,LocalDateTime end);
	 
	List<ApiAuditEntity> findByTransactionIdInOrderByCreatedOnAsc( List<String> transactionIds );
	
	
//	List<ApiAuditEntity> findByCreatedOnBetweenOrderByCreatedOnAsc(LocalDateTime start,LocalDateTime end);
	 
	List<ApiAuditEntity> findByTypeAndActionAndCreatedOnBetweenOrderByCreatedOnAsc(String type,String action,LocalDateTime start,LocalDateTime end);

	
	@Query( value = " select "
			+ "       DISTINCT ON  (transaction_id) transaction_id transactionId , created_on createdOn "
			+ "    from (select transaction_id,created_on from "
			+ "        api_audit  where created_on between ?1 and ?2 "
			+ "    order by "
			+ "        created_on desc ) a", nativeQuery = true)
	List<ApiAuditEntityProjecttion>  selectByCreatedOnBetween(LocalDateTime start,LocalDateTime end);
	
	Integer countByCreatedOnBetween(LocalDateTime start,LocalDateTime end);
	
	@Query(value = " select "
			+ "       DISTINCT ON  (transaction_id) transaction_id "
			+ "    from (select transaction_id from "
			+ "        api_audit  "
			+ "    order by "
			+ "        created_on desc limit 10000) a", nativeQuery = true)
	public List<String> getDistinctId();
	
	@Query( value = " Select  seller_id sellerId, count(1) from api_audit where seller_id is not null and "
			+ "type = 'RESPONSE_BY_SELLER' and created_on between ?1 and ?2 GROUP BY seller_id  order by count desc", nativeQuery = true)
	List<ApiAuditEntitySellerProjection>  selectBySellerCreatedOnBetween(LocalDateTime start,LocalDateTime end);
	
	@Query( value = " Select  buyer_id buyerId, count(1) from api_audit where seller_id is not null and "
			+ "type = 'RESPONSE_TO_BUYER' and created_on between ?1 and ?2 GROUP BY buyer_id  order by count desc", nativeQuery = true)
	List<ApiAuditEntityBuyerProjection>  selectByBuyerCreatedOnBetween(LocalDateTime start,LocalDateTime end);
	
}
