package com.nsdl.beckn.np.model.response;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.nsdl.beckn.np.model.NetworkParticipantMaster;
import com.nsdl.beckn.np.utl.Constants;

import lombok.Data;

@Data
public class ResponseNetworkParticipant {
	@JsonProperty("subscriber_url")
	String subscriberUrl;
	@JsonProperty("domain")
	String domain;
//	@JsonProperty("callback_url")
//	String callbackUrl;
	@JsonProperty("type")
	String type;
	@JsonProperty("msn")
	boolean msn;
	@JsonProperty("city_code")
	List<String> cityCode;
	@JsonProperty("seller_on_record")
	List<ResponseSellerOnRecord> sellerOnRecordMasters = new ArrayList<>();

	public ResponseNetworkParticipant(NetworkParticipantMaster np) {
		this.subscriberUrl = np.getSubscriberUrl();
		this.domain = np.getDomain();
		// this.callbackUrl = np.getCallbackUrl();
		this.type = np.getType();
		this.msn = np.isMsn();

		this.cityCode = np.getCityCode();
		np.getSellerOnRecordMasters().forEach(item -> {
			if (Constants.STATUS_SUBSCRIBED.equals(item.getStatus())) {
				this.sellerOnRecordMasters.add(new ResponseSellerOnRecord(item));
			}

		});
	}

}
