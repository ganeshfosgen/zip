package test;

import java.io.IOException;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

import com.nsdl.signing.crypto.EncryptDecrypt;
import com.nsdl.signing.model.RequestEncDecryptData;

public class test {
	public static void caheRefresh(String cacheReloadUrl) {
		CloseableHttpClient httpClient = HttpClients.createDefault();

		try {

			if (cacheReloadUrl.indexOf("cache-reload") != -1) {
				HttpGet request = new HttpGet(cacheReloadUrl);

				CloseableHttpResponse response = httpClient.execute(request);

				System.out.println(response.getStatusLine().getStatusCode()); // 200

				if (response.getStatusLine().getStatusCode() == 200) {
					System.out.println("caheRefresh" + cacheReloadUrl + ":ok");
					// body.getMsgError().put("caheRefresh", cacheReloadUrl + ":ok");
				} else {

					System.out.println("caheRefresh" + cacheReloadUrl + ":ERROR:"
							+ response.getStatusLine().getStatusCode() + response.getStatusLine().toString());
//				body.getMsgError().put("caheRefresh", cacheReloadUrl + ":ERROR:"
//						+ response.getStatusLine().getStatusCode() + response.getStatusLine().toString());
				}
			} else {

				HttpPost request = new HttpPost(cacheReloadUrl);

				String json = " { \"key\": \"beckn-api-cache-lookup\" }";
				StringEntity entity = new StringEntity(json);
				request.setEntity(entity);
				request.setHeader("Accept", "application/json");
				request.setHeader("Content-type", "application/json");

				CloseableHttpResponse response = httpClient.execute(request);

				System.out.println(response.getStatusLine().getStatusCode()); // 200

				if (response.getStatusLine().getStatusCode() == 200) {
					System.out.println("caheRefresh" + cacheReloadUrl + ":ok");
					// body.getMsgError().put("caheRefresh", cacheReloadUrl + ":ok");
				} else {

					System.out.println("caheRefresh" + cacheReloadUrl + ":ERROR:"
							+ response.getStatusLine().getStatusCode() + response.getStatusLine().toString());
//				body.getMsgError().put("caheRefresh", cacheReloadUrl + ":ERROR:"
//						+ response.getStatusLine().getStatusCode() + response.getStatusLine().toString());
				}

			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("caheRefresh_exception" + cacheReloadUrl + ":" + e.getMessage());

//			body.getMsgError().put("caheRefresh_exception", cacheReloadUrl + ":" + e.getMessage());

			e.printStackTrace();
		} finally {
			try {
				httpClient.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	public static void main(String[] args) {
		caheRefresh("https://gateway.ondc.org/cache-evict");
	}
}
