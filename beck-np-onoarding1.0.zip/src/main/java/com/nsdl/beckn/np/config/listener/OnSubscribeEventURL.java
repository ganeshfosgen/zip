package com.nsdl.beckn.np.config.listener;

import java.io.Serializable;

import org.springframework.context.ApplicationEvent;

public class OnSubscribeEventURL  extends ApplicationEvent implements Serializable {
 

	public OnSubscribeEventURL(Object source) {
		super(source); 
		// TODO Auto-generated constructor stub
	}
}
