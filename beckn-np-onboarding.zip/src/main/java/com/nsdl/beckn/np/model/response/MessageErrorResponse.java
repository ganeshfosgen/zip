package com.nsdl.beckn.np.model.response;

import com.nsdl.beckn.np.utl.Constants;

import lombok.Data;

@Data
public class MessageErrorResponse extends MessageResponse {
	String errCode;
	String details;
	public static MessageResponse errorOCSP() {
		MessageErrorResponse response = new MessageErrorResponse();
		response.errCode = Constants.RESPONSE_ONBORDING_REQUEST_OCSP_ERROR[0];
		response.details = Constants.RESPONSE_ONBORDING_REQUEST_OCSP_ERROR[1];
		return response;
	}
	
	public static MessageResponse errorReqID() {
		MessageErrorResponse response = new MessageErrorResponse();
		response.errCode = Constants.RESPONSE_ONSUBSCRIBE_REQUEST_ERROR[0];
		response.details = Constants.RESPONSE_ONSUBSCRIBE_REQUEST_ERROR[1];
		return response;
	}
	
	public static MessageResponse errorSubscribeID() {
		MessageErrorResponse response = new MessageErrorResponse();
		response.errCode = Constants.RESPONSE_ONSUBSCRIBE_SUBSCRIBE_ID_ERROR[0];
		response.details = Constants.RESPONSE_ONSUBSCRIBE_SUBSCRIBE_ID_ERROR[1];
		return response;
	}
	
	public static MessageResponse errorSVerifyKInit() {
		MessageErrorResponse response = new MessageErrorResponse();
		 
		response.errCode = Constants.RESPONSE_VERIFYK_SIG_INIT_ERROR[0];
		response.details = Constants.RESPONSE_VERIFYK_SIG_INIT_ERROR[1];
		return response;
	}
	public static MessageResponse error() {
		MessageErrorResponse response = new MessageErrorResponse();
		response.errCode = Constants.RESPONSE_ONBORDING_REQUEST_ERROR[0];
		response.details = Constants.RESPONSE_ONBORDING_REQUEST_ERROR[1];
		return response;
	}

	public static MessageResponse errorVerifyDomain(String ackCode) {
		MessageErrorResponse response = new MessageErrorResponse();
		response.errCode = Constants.RESPONSE_VERIFY_DOMAIN_ERROR[0];
		response.details = Constants.RESPONSE_VERIFY_DOMAIN_ERROR[1];
		return response;
	}
	

	public static MessageResponse errorEncrVerifyKInit() {
		MessageErrorResponse response = new MessageErrorResponse();
		 
		response.errCode = Constants.RESPONSE_VERIFYK_ENCRYPT_INIT_ERROR[0];
		response.details = Constants.RESPONSE_VERIFYK_ENCRYPT_INIT_ERROR[1];
		return response;
	}
	
	public static MessageResponse errorLookup() {
		MessageErrorResponse response = new MessageErrorResponse();
		 
		response.errCode = Constants.RESPONSE_LOOKP_ERROR[0];
		response.details = Constants.RESPONSE_LOOKP_ERROR[1];
		return response;
	}

}
