package com.nsdl.beckn.np.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nsdl.beckn.np.model.MessageResponse;
import com.nsdl.beckn.np.model.request.ReqDinit;
import com.nsdl.beckn.np.model.request.ReqDverify;
import com.nsdl.beckn.np.model.request.ReqKinit;
import com.nsdl.beckn.np.model.request.ReqLookup;
import com.nsdl.beckn.np.model.response.Response;
import com.nsdl.beckn.np.service.OnboardingService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/ondc")
@Slf4j
public class OnboardingController {
	@Autowired
	OnboardingService onboardingService;
 

	 
	@PostMapping("/verifyParticipant/verifyD/init")
	public ResponseEntity<Response<MessageResponse>> verifyDInit(@RequestBody ReqDinit reqDinit) {
		return Response.ok(onboardingService.verifyDInit(reqDinit),onboardingService);
	}
	
	@PostMapping("/verifyParticipant/verifyD/verify")
	public ResponseEntity<Response<MessageResponse>> verifyDVerify(@RequestBody ReqDverify reqDverify) {
		return Response.ok(onboardingService.verifyDVerify(reqDverify),onboardingService);
	}
	
	@PostMapping("/verifyParticipant/verifyK/init")
	public ResponseEntity<Response<MessageResponse>> verifyKInit(@RequestBody ReqKinit reqKinit) {
		return Response.ok(onboardingService.verifyKInit(reqKinit),onboardingService);
	}
	
	
	@PostMapping("/lookup")
	public ResponseEntity<Response<MessageResponse>> lookup(@RequestBody ReqLookup reqLookup) {
		return Response.ok(onboardingService.lookup(reqLookup),onboardingService);
	}
	
	@PostMapping("/generate/registry/key")
	public ResponseEntity<Response<String>> generateKey() {
		return Response.ok(onboardingService.initRKey() ,onboardingService);
	}

}
