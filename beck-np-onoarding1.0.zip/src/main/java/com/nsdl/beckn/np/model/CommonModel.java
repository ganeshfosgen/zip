package com.nsdl.beckn.np.model;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Data;

@Data
@MappedSuperclass
public class CommonModel {
	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "id", columnDefinition = "char(36)")
	@Type(type = "org.hibernate.type.UUIDCharType" )	
	UUID id;

	@Column(name = "api_vrsn")
	Integer apiVersion = 1;
	
	@Column(name = "vrsn")
	Integer version = 1;

	@Column(name = "actv")
	Boolean active = true;
	
	@Column(name = "sft_dlt")
	Boolean softDelete = false;

	@Column(name = "crtd_by", columnDefinition = "char(36)")
	UUID createdBy;

	@CreationTimestamp
	@Column(name = "crt_tm_stmp", columnDefinition = "TIMESTAMP WITH TIME ZONE")
	OffsetDateTime createdDate;

	@Column(name = "updtd_by", columnDefinition = "char(36)")
	UUID updatedBy;

	@UpdateTimestamp
	@Column(name = "updtd_tm_stmp", columnDefinition = "TIMESTAMP WITH TIME ZONE")
	OffsetDateTime updatedDate;
	
	
	@Column(name = "src_ip")
	String sourceIp;
	
	@Column(name = "updtd_src_ip")
	String updatedSourceIp;
}
