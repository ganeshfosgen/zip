package com.nsdl.beckn.np.service.impl;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.nsdl.beckn.np.dao.NPApiLogsRepository;
import com.nsdl.beckn.np.dao.NPMasterRepository;
import com.nsdl.beckn.np.dao.NPOnboardingRequestRepository;
import com.nsdl.beckn.np.dao.RegistryRepository;
import com.nsdl.beckn.np.model.MessageErrorResponse;
import com.nsdl.beckn.np.model.MessageResponse;
import com.nsdl.beckn.np.model.MessageSucessResponse;
import com.nsdl.beckn.np.model.NPApiLogs;
import com.nsdl.beckn.np.model.NPMaster;
import com.nsdl.beckn.np.model.NPOnboardingRequest;
import com.nsdl.beckn.np.model.RegistryEnum;
import com.nsdl.beckn.np.model.RegistryKeys;
import com.nsdl.beckn.np.model.request.ReqDinit;
import com.nsdl.beckn.np.model.request.ReqDverify;
import com.nsdl.beckn.np.model.request.ReqKinit;
import com.nsdl.beckn.np.model.request.ReqLookup;
import com.nsdl.beckn.np.model.request.ReqSubscribe;
import com.nsdl.beckn.np.service.OnboardingService;
import com.nsdl.beckn.np.utl.CommonUtl;
import com.nsdl.beckn.np.utl.Constants;
import com.nsdl.beckn.np.utl.SecurityUtils;
import com.nsdl.signing.crypto.EncryptDecrypt;
import com.nsdl.signing.crypto.GeneratePayload;
import com.nsdl.signing.model.KeyData;
import com.nsdl.signing.model.RequestEncDecryptData;
import com.nsdl.signing.model.Web;
import com.nsdl.signing.service.CryptoService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class OnboardingServiceImpl implements OnboardingService {

	@Autowired
	SecurityUtils securityUtils;

	@Autowired
	CryptoService cryptoService;

	@Autowired
	NPApiLogsRepository logsRepository;

	@Autowired
	RegistryRepository registryRepository;

	@Autowired
	NPMasterRepository masterRepository;

	@Autowired
	NPOnboardingRequestRepository onboardingRequestRepository;

	@Autowired
	Gson gson;

	@Autowired
	EncryptDecrypt encryptDecrypt;

	public NPApiLogs saveLogs(Object req) {
		NPApiLogs logs = new NPApiLogs();
		securityUtils.initCommonProperties(logs);
		logs.setJsonRequest(CommonUtl.convertObjectToMap(req));
		logs.setType(securityUtils.getUserDetails().getLogsType());
		logsRepository.save(logs);
		securityUtils.setLogId(logs.getId());
		return logs;

	}

	public boolean verifyDomain(NPApiLogs log, String ackCode) {
		boolean verify = false;
		try {

			if (log.getJsonRequest().get("domain") != null) {

				URL u = null;
				try {
					u = new URL(
							"https://" + log.getJsonRequest().get("domain").toString() + "/ondc-siteverification.html");
				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if (u != null) {
					try (InputStream in = u.openStream()) {
						String data = new String(in.readAllBytes(), StandardCharsets.UTF_8);
						verify = data.indexOf("'" + ackCode + "'") != -1;
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		return verify;
	}

	@Override
	public void saveLogsResponse(ResponseEntity resonse) {
		// TODO Auto-generated method stub
		NPApiLogs log = logsRepository.getById(securityUtils.getUserDetails().getLogsId());
		log.setJsonResponse(CommonUtl.convertObjectToMap(resonse));
		logsRepository.save(log);

	}

	@Override
	public void saveLogsResponseTime(Integer time) {
		// TODO Auto-generated method stub
		NPApiLogs log = logsRepository.getById(securityUtils.getUserDetails().getLogsId());
		log.setResponseTime(time);
		logsRepository.save(log);

	}

	@Override
	public MessageResponse verifyDInit(ReqDinit reqDinit) {
		MessageResponse response = null;
		try {

			NPApiLogs logs = saveLogs(reqDinit);

			String ocspStatus = cryptoService.checkOCSP(new Web(reqDinit.getSubscriberUrl()));

			if (!Constants.OCSP_NOT_VALID.equals(ocspStatus)) {

				List<NPOnboardingRequest> list = onboardingRequestRepository.findByConfReqId(reqDinit.getConfReqID());
				NPOnboardingRequest request = null;
				if (list.size() == 0) {
					request = new NPOnboardingRequest();
					securityUtils.initCommonProperties(request);
					request.setSubscriberId(reqDinit.getSubscriberId());
					request.setDInitAckCode(UUID.randomUUID().toString());
					request.setApiLogsId(logs.getId());
					request.setConfReqId(reqDinit.getConfReqID());
					onboardingRequestRepository.save(request);
				} else {
					request = list.get(0);
					securityUtils.initCommonProperties(request);
					request.setApiLogsId(logs.getId());
					request.setSubscriberId(reqDinit.getSubscriberId());
					onboardingRequestRepository.save(request);

				}
				response = MessageSucessResponse.ok(request.getDInitAckCode());
			} else {
				response = MessageErrorResponse.errorOCSP();
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			log.info("{} error {} ", "verifyD/Init", e.getMessage());

			response = MessageErrorResponse.errorOCSP();
		}
		return response;
	}

	@Override
	public MessageResponse verifyDVerify(ReqDverify reqDverify) {
		MessageResponse reponse = new MessageResponse();
		List<NPOnboardingRequest> list = onboardingRequestRepository.findByConfReqId(reqDverify.getConfReqID());
		String data = null;
		NPMaster master = null;

		boolean verify = false;
		try {
			NPApiLogs logs = saveLogs(reqDverify);
			if (list.size() > 0) {
				NPOnboardingRequest onboardingRequest = list.get(0);
				logs = logsRepository.getById(onboardingRequest.getApiLogsId());
				if (logs != null) {
					List<NPMaster> listMaster = masterRepository
							.findBySubscriberId(onboardingRequest.getSubscriberId());
					if (listMaster.size() != 0) {
						master = listMaster.get(0);
					} else {
						master = new NPMaster();
						master.setKeyVerification(UUID.randomUUID().toString());
					}
					securityUtils.initCommonProperties(master);
					if (onboardingRequest.getDInitAckCode().equals(reqDverify.getDInitAckCode()))
						verify = verifyDomain(logs, reqDverify.getDInitAckCode());
					master.loadFromLogs(logs, reqDverify, onboardingRequest);
					master.setUnderDomainVerification(verify);
					masterRepository.save(master);

				}

			}
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		if (verify) {
			reponse = MessageSucessResponse.okVerifyDomain(reqDverify.getDInitAckCode(), master.getKeyVerification());
		} else {
			reponse = MessageErrorResponse.errorVerifyDomain(reqDverify.getDInitAckCode());

		}
		return reponse;
	}

	@Override
	public MessageResponse verifyKInit(ReqKinit reqKinit) {
		MessageResponse reponse = new MessageResponse();
		boolean verifySignature = false;
		boolean verifyEncryption = false;
		NPMaster master = null;
		try {
			NPApiLogs logs = saveLogs(reqKinit);
			List<NPMaster> list = masterRepository.findByKeyVerification(reqKinit.getDVerifyAckCode());

			if (list.size() > 0) {
				master = list.get(0);

				String blakeValue = GeneratePayload.generateBlakeHash(master.getKeyVerification());

				verifySignature = GeneratePayload.verifySignaturePK(reqKinit.getSignature(), blakeValue,
						master.getSigningPublicKey());

				List<RegistryKeys> listReg = registryRepository.findAllByType(RegistryEnum.ENCRYPTION);
				if (listReg.size() > 0) {
					RequestEncDecryptData requestEncDecryptData = new RequestEncDecryptData();
					requestEncDecryptData.setValue(reqKinit.getEncMessage());
					requestEncDecryptData.setClientPublicKey(master.getEncrPublicKey());
					requestEncDecryptData.setProteanPrivateKey(listReg.get(0).getPrivateKey());

					String decrStr = encryptDecrypt.decrypt(requestEncDecryptData);
					verifyEncryption = master.getKeyVerification().equals(decrStr);

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (verifyEncryption && verifySignature && master != null) {

			reponse = MessageSucessResponse.okVerifyKInit(UUID.randomUUID().toString());
		} else if (!verifySignature) {
			reponse = MessageErrorResponse.errorSVerifyKInit();

		} else {
			reponse = MessageErrorResponse.errorEncrVerifyKInit();

		}
		return reponse;
	}

	@Override
	public MessageResponse lookup(ReqLookup reqLookup) {
		MessageResponse reponse = new MessageResponse();
		List<NPMaster> list = masterRepository.findBySubscriberId(reqLookup.getSubscriberId());
		if (list.size() == 0) {

		} else {

		}
		return reponse;
	}

	@Override
	public String initRKey() {
		KeyData key = cryptoService.generateSignKey();
		NPApiLogs logs = saveLogs(new RegistryKeys());
		RegistryKeys rKey = new RegistryKeys();
		securityUtils.initCommonProperties(rKey);
		rKey.setPrivateKey(key.getPrivateKey());
		rKey.setPublicKey(key.getPublicKey());
		rKey.setType(RegistryEnum.SIGNING);
		registryRepository.save(rKey);

		key = cryptoService.generateEncrypDecryptKey();
		rKey = new RegistryKeys();
		securityUtils.initCommonProperties(rKey);
		rKey.setPrivateKey(key.getPrivateKey());
		rKey.setPublicKey(key.getPublicKey());
		rKey.setType(RegistryEnum.ENCRYPTION);
		registryRepository.save(rKey);

		return "ok";
	}

	@Override
	public MessageResponse onSubScribe(ReqSubscribe reqSubscribe) {
		MessageResponse response = null;
		try {

			NPApiLogs logs = saveLogs(reqSubscribe);

			String ocspStatus = cryptoService.checkOCSP(new Web(reqSubscribe.getDomain()));

			if (!Constants.OCSP_NOT_VALID.equals(ocspStatus)) {

				List<NPOnboardingRequest> list = onboardingRequestRepository
						.findByConfReqId(reqSubscribe.getPreviousReqId());
				NPOnboardingRequest request = null;
				if (list.size() > 0) {

					List<NPMaster> listMaster = masterRepository.findBySubscriberId(reqSubscribe.getSubscriberId());

					if (listMaster.size() > 0) {
						NPMaster master =listMaster.get(0);
						String blakeValue = GeneratePayload.generateBlakeHash(master.getKeyVerification());

						boolean verifySignature = GeneratePayload.verifySignaturePK(reqSubscribe.getSignature(),
								blakeValue, master.getSigningPublicKey());
						if(verifySignature) {
							
						}else {
							return MessageErrorResponse.errorSubscribeID();
						}
//						request = new NPOnboardingRequest();
//						securityUtils.initCommonProperties(request);
//						request.setSubscriberId(reqDinit.getSubscriberId());
//						request.setDInitAckCode(UUID.randomUUID().toString());
//						request.setApiLogsId(logs.getId());
//						request.setConfReqId(reqDinit.getConfReqID());
//						onboardingRequestRepository.save(request);
					}else {
						return MessageErrorResponse.errorSubscribeID();
					}
				} else {
					return MessageErrorResponse.errorReqID();
				}
				response = MessageSucessResponse.ok(request.getDInitAckCode());
			} else {
				response = MessageErrorResponse.errorOCSP();
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			log.info("{} error {} ", "verifyD/Init", e.getMessage());

			response = MessageErrorResponse.errorOCSP();
		}
		return response;
	}

}
