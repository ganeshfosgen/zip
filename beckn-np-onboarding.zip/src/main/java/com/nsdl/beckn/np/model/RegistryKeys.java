package com.nsdl.beckn.np.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

import lombok.Data;

@Entity
@Table(name = "registry_keys")
@Data
@Where(clause = "sft_dlt=false")
@SQLDelete(sql = "update registry_keys   set sft_dlt=true where id=?")
public class RegistryKeys extends CommonModel {

	@Column(name = "pblc_ky")
	String publicKey;

	@Column(name = "prvt_ky")
	String privateKey;

	@Column(name = "typ")
	@Enumerated(EnumType.STRING)
	RegistryEnum type; // Encryption, Signing

}
