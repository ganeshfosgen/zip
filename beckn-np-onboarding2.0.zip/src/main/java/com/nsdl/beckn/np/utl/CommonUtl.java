package com.nsdl.beckn.np.utl;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;

public class CommonUtl {
	public static String parseDomainNamefromUrl(String url) {
//	    if (url == null) return null;
//	    URL rawUrl = null;
//	    try {
//	        rawUrl = new URL(url);
//	    } catch (MalformedURLException e) {
//	        System.out.println("ERROR - failed to create URL from url=" + url);
//	        System.out.println(e.getMessage());
//	        e.printStackTrace();
//	        return url;
//	    }
//	    String host = rawUrl.getHost();
//	    InternetDomainName idn = InternetDomainName.from(host);
//	    while (idn.isTopPrivateDomain() == false && (idn.hasParent()) ) {
//	        idn = idn.parent();
//	    }
//	    String domain = idn.toString();
//	    if (idn.isUnderPublicSuffix()) {
//	        domain =idn.topPrivateDomain().toString();
//	    }
//	    System.out.println("Parsed domain: " + domain);
//	    return domain;
		try {

			URL aURL = new URL(url);
			return aURL.getAuthority();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return "";

	}

	public static String getSig(String url, Map<String, String> error) {
		URL u = null;
		error.put("Signature_urk", url + "/ondc-site-verification.html");
		try {
			u = new URL(url + "/ondc-site-verification.html");
			// System.out.println("URL : " + u.getProtocol() + "://" + u.getAuthority() +
			// "/ondc-site-verification.html");
			// u = new URL(u.getProtocol() + "://" + u.getAuthority() +
			// "/ondc-site-verification.html");

		} catch (MalformedURLException e1) {
			// TODO Auto-generated catch block
			// e1.printStackTrace();
			error.put("Signature_MalformedURLException", e1.getMessage());

			System.out.println("ERROR URL " + u.getPath() + " error {} " + e1.getMessage());

			// Log.error(e1.getMessage());
		}
		if (u != null) {
			try (InputStream in = u.openStream()) {
				String data = new String(in.readAllBytes(), StandardCharsets.UTF_8);
				int index = data.indexOf("content='");
				if (index != -1) {
					String sig = data.substring(index + 9, data.indexOf("'", index + 12));
					System.out.println("sig:" + sig);
					return sig;

				}
				// verify = data.indexOf("'" + ackCode + "'") != -1;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
				error.put("Signature_IOException", e.getMessage());

				System.out.println("ERROR URL " + u.getPath() + " error {} " + e.getMessage());

			}
		}
		error.put("Signature_NOTFOUND", "Signature not found");
		return null;
	}

	public static OffsetDateTime getDate(String start) {
		if ((start == null) || "".equals(start)) {
			return null;
		}
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		LocalDateTime st;
		try {
			st = LocalDateTime.parse(start, formatter);
			return OffsetDateTime.of(st, ZoneOffset.UTC);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();

		}
		return null;
	}

	public static String getDateString(OffsetDateTime date) {
		if ((date == null)) {
			return null;
		}
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		LocalDateTime st;
		try {

			return formatter.format(date);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();

		}
		return null;
	}

	public static LocalDate getLocalDate(String start) {
		if ((start == null) || "".equals(start)) {
			return null;
		}
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate st;
		try {
			st = LocalDate.parse(start, formatter);
			return st;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();

		}
		return null;
	}

	public static boolean validTimeDate(String start, int window) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		LocalDateTime st = null;
		try {
			st = LocalDateTime.parse(start, formatter);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if ((st != null) && LocalDateTime.now().minusMinutes(window).isBefore(st)
				&& st.isBefore(LocalDateTime.now().plusMinutes(window))) {
			return true;
		}
		return false;
	}

	public static String checkDate(String start, String end) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		// formatter.parse(start).get();
		LocalDateTime st;
		try {
			st = LocalDateTime.parse(start, formatter);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return "Start Date is Invalid date time format.";
		}
		if ((end != null) && !"".equals(end)) {
			LocalDateTime ed;
			try {
				ed = LocalDateTime.parse(end, formatter);
			} catch (Exception e) {
				// TODO: handle exception
				return "End Date is Invalid date time format.";
			}
			if (st.isBefore(ed)) {
				return null;
			} else {
				return "Start Date should be less than end date.";
			}
		}
		return null;
	}

	public static Map<String, Object> convertObjectToMap(Object obj) {
		Gson gson = new Gson();
		return gson.fromJson(gson.toJson(obj), Map.class);

	}

	public static void main(String[] args) {
		System.out.println(new CommonUtl().getSig("https://craftsvilla.com", new HashMap<>()));
	}

}
