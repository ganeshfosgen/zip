package com.nsdl.beckn.np.config.listener;

import java.io.Serializable;
import java.util.UUID;

import org.springframework.context.ApplicationEvent;

import com.nsdl.beckn.np.model.NPMaster;
import com.nsdl.beckn.np.model.NPSubscribeRequest;
import com.nsdl.beckn.np.model.request.ReqSubscribe;

public class OnSubscribeEvent  extends ApplicationEvent implements Serializable {
	NPSubscribeRequest subscription;
	NPMaster master ;
	ReqSubscribe reqSubscribe;
	UUID id;
	String ip;
	
	public OnSubscribeEvent(Object source,NPSubscribeRequest subscription,
			NPMaster master,ReqSubscribe reqSubscribe,UUID id,String ip) {
		super(source);
		this.subscription=subscription;		
		this.master=master;
		this.reqSubscribe=reqSubscribe;
		this.id=id;
		this.ip=ip;
		// TODO Auto-generated constructor stub
	}

}
