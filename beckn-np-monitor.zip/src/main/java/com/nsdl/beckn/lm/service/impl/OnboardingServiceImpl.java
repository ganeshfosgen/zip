package com.nsdl.beckn.lm.service.impl;

import java.io.ByteArrayOutputStream;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nsdl.beckn.lm.dao.lookup.NPApiLogsRepository;
import com.nsdl.beckn.lm.dao.transaction.ApiAuditRepository;
import com.nsdl.beckn.lm.model.FileBo;
import com.nsdl.beckn.lm.model.Graph;
import com.nsdl.beckn.lm.model.lookup.NPApiLogs;
import com.nsdl.beckn.lm.model.projection.ApiAuditEntityBuyerProjection;
import com.nsdl.beckn.lm.model.projection.ApiAuditEntityProjecttion;
import com.nsdl.beckn.lm.model.projection.ApiAuditEntitySellerProjection;
import com.nsdl.beckn.lm.model.request.LogsRequest;
import com.nsdl.beckn.lm.model.response.LogsResponse;
import com.nsdl.beckn.lm.model.transaction.ApiAuditEntity;
import com.nsdl.beckn.lm.service.ApiAuditService;
import com.nsdl.beckn.lm.utl.CommonUtl;
import com.nsdl.beckn.lm.utl.Constants;
import com.nsdl.beckn.lm.utl.SecurityUtils;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j

public class OnboardingServiceImpl implements ApiAuditService, ApplicationContextAware {

	@Value("${com.nsdl.logs.monitor.years}")
	String years;
	@Value("${com.nsdl.logs.monitor.months}")
	String months;
	@Value("${com.nsdl.logs.monitor.weeks}")
	String weeks;
	@Value("${com.nsdl.logs.monitor.days}")
	String days;

	@Autowired
	SecurityUtils securityUtils;

	@Autowired
	ApiAuditRepository apiAuditRepository;

	@Autowired
	NPApiLogsRepository apiLogsRepository;

	private ApplicationContext applicationContext;
	@Autowired
	@Qualifier("lookupEntityManagerFactory")
	private EntityManager entityManager;

//	@PersistenceContext
//	public void setEntityManager(@Qualifier("lookupEntityManagerFactory") EntityManager entityMgr) {
//		this.entityManager = entityMgr;
//	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}

	public Map<String, List<Map<String, Object>>> getTransationList(List<ApiAuditEntity> list) {
		Map<String, List<Map<String, Object>>> map = new HashMap<>();
		map.put(Constants.Buyer_to_Gateway, new ArrayList<Map<String, Object>>());
		map.put(Constants.Gateway_to_Seller, new ArrayList<Map<String, Object>>());
		map.put(Constants.Seller_to_Gateway, new ArrayList<Map<String, Object>>());
		map.put(Constants.Gateway_to_Buyer, new ArrayList<Map<String, Object>>());

		Map<String, Boolean> mapFlag = new HashMap<>();
		Map<String, Map<String, Object>> lastRecord = new HashMap<>();
		list.forEach(item -> {
			if (Constants.REQUEST_BY_BUYER.equals(item.getType()) || Constants.ACK_TO_BUYER.equals(item.getType())
					|| Constants.NACK_TO_BUYER.equals(item.getType())) {

				if (Constants.REQUEST_BY_BUYER.equals(item.getType())) {
					Map<String, Object> record = new HashMap<>();
					record.put(Constants.col_Transaction_id, item.getTransactionId());
					record.put(Constants.col_Buyer_Id, item.getBuyerId());
					record.put(Constants.col_Search_received_timestamp,
							CommonUtl.convertDatetoString(item.getCreatedOn()));
					record.put(Constants.col_Buyer_Status, item.getType());
					record.put(Constants.col_message_id, item.getMessageId());
					record.put(Constants.col_sender_rec_id, item.getId());

					lastRecord.put(item.getTransactionId() + Constants.Buyer_to_Gateway + item.getMessageId(), record);
					map.get(Constants.Buyer_to_Gateway).add(record);
				} else {
					Map<String, Object> record = lastRecord
							.get(item.getTransactionId() + Constants.Buyer_to_Gateway + item.getMessageId());
					if (record != null) {
						if (mapFlag.get(
								item.getTransactionId() + Constants.Buyer_to_Gateway + item.getMessageId()) != null) {
							record = CommonUtl.mapClone(record);
							map.get(Constants.Buyer_to_Gateway).add(record);
						}
						record.put(Constants.col_Ack_Returned_Timestamp,
								CommonUtl.convertDatetoString(item.getCreatedOn()));
						record.put(Constants.col_Gatway_Status, item.getType());
						record.put(Constants.col_ack_rec_id, item.getId());
						record.put(Constants.col_error, item.getError());
						mapFlag.put(item.getTransactionId() + Constants.Buyer_to_Gateway + item.getMessageId(), true);
						// lastRecord.remove(Constants.Gateway_to_Seller+item.getMessageId());
					} else {
						System.out.println(item.getTransactionId() + ":" + item.getType());
					}
				}
			} else if (Constants.REQUEST_TO_SELLER.equals(item.getType())
					|| Constants.ACK_BY_SELLER.equals(item.getType())
					|| Constants.ERROR_CALLING_SELLER.equals(item.getType())) {
//tran + buyeid + messagid+action
				String key = item.getTransactionId() + ":" + item.getBuyerId() + ":" + item.getSellerId() + ":"
						+ item.getAction() + Constants.Gateway_to_Seller + item.getMessageId();
				if (Constants.REQUEST_TO_SELLER.equals(item.getType())) {
					Map<String, Object> record = new HashMap<>();
					record.put(Constants.col_Transaction_id, item.getTransactionId());
					record.put(Constants.col_Seller_Id, item.getSellerId());
					record.put(Constants.col_Search_received_timestamp,
							CommonUtl.convertDatetoString(item.getCreatedOn()));
					record.put(Constants.col_Gatway_Status, item.getType());
					record.put(Constants.col_message_id, item.getMessageId());
					lastRecord.put(key, record);
					map.get(Constants.Gateway_to_Seller).add(record);
				} else {
					Map<String, Object> record = lastRecord.get(key);
					if (record != null) {
						if (mapFlag.get(key) != null) {
							record = CommonUtl.mapClone(record);
							map.get(Constants.Gateway_to_Seller).add(record);
						}
						record.put(Constants.col_error, item.getError());
						record.put(Constants.col_Ack_Returned_Timestamp,
								CommonUtl.convertDatetoString(item.getCreatedOn()));
						record.put(Constants.col_Seller_Status, item.getType());
						mapFlag.put(key, true);

						// lastRecord.remove(Constants.Gateway_to_Seller+item.getMessageId());
					} else {
						System.out.println(item.getTransactionId() + ":" + item.getType());
					}
				}
			} else if (Constants.RESPONSE_BY_SELLER.equals(item.getType())
					|| Constants.ACK_TO_SELLER.equals(item.getType())) {
//status
				String key = item.getTransactionId() + ":" + item.getBuyerId() + ":" + item.getSellerId() + ":"
						+ item.getAction() + Constants.Seller_to_Gateway + item.getMessageId();

				if (Constants.RESPONSE_BY_SELLER.equals(item.getType())) {
					Map<String, Object> record = new HashMap<>();
					record.put(Constants.col_Transaction_id, item.getTransactionId());
					record.put(Constants.col_Seller_Id, item.getSellerId());
					record.put(Constants.col_Search_received_timestamp,
							CommonUtl.convertDatetoString(item.getCreatedOn()));
					record.put(Constants.col_Seller_Status, item.getType());
					record.put(Constants.col_message_id, item.getMessageId());
					lastRecord.put(key, record);
					map.get(Constants.Seller_to_Gateway).add(record);
				} else {
					Map<String, Object> record = lastRecord.get(key);
					if (record != null) {
						if (mapFlag.get(key) != null) {
							record = CommonUtl.mapClone(record);
							map.get(Constants.Seller_to_Gateway).add(record);
						}
						record.put(Constants.col_error, item.getError());
						record.put(Constants.col_Ack_Returned_Timestamp,
								CommonUtl.convertDatetoString(item.getCreatedOn()));
						record.put(Constants.col_Gatway_Status, item.getType());
						// lastRecord.remove(Constants.Seller_to_Gateway+item.getMessageId());
						mapFlag.put(key, true);
					} else {
						System.out.println(item.getTransactionId() + ":" + item.getType());
					}
				}
			} else if (Constants.RESPONSE_TO_BUYER.equals(item.getType())
					|| Constants.NACK_BY_BUYER.equals(item.getType()) || Constants.ACK_BY_BUYER.equals(item.getType())
					|| Constants.ERROR_CALLING_BUYER.equals(item.getType())
					|| Constants.BLOCKED_BUYER.equals(item.getType())) {
				String key = item.getTransactionId() + ":" + item.getBuyerId() + ":" + item.getSellerId() + ":"
						+ item.getAction() + Constants.Gateway_to_Buyer + item.getMessageId();

				if (Constants.RESPONSE_TO_BUYER.equals(item.getType())) {
					Map<String, Object> record = new HashMap<>();
					record.put(Constants.col_Transaction_id, item.getTransactionId());
					record.put(Constants.col_Seller_Id, item.getSellerId());
					record.put(Constants.col_Buyer_Id, item.getBuyerId());
					record.put(Constants.col_message_id, item.getMessageId());
					record.put(Constants.col_Search_received_timestamp,
							CommonUtl.convertDatetoString(item.getCreatedOn()));
					record.put(Constants.col_Gatway_Status, item.getType());
					lastRecord.put(key, record);
					map.get(Constants.Gateway_to_Buyer).add(record);
				} else {
					Map<String, Object> record = lastRecord.get(key);
					if (record != null) {
						if (mapFlag.get(key) != null) {
							record = CommonUtl.mapClone(record);
							map.get(Constants.Gateway_to_Buyer).add(record);
						}
						record.put(Constants.col_error, item.getError());
						record.put(Constants.col_Ack_Returned_Timestamp,
								CommonUtl.convertDatetoString(item.getCreatedOn()));
						record.put(Constants.col_Buyer_Status, item.getType());
						mapFlag.put(key, true);
						// lastRecord.remove(Constants.Gateway_to_Buyer+item.getMessageId());
					} else {
						System.out.println(item.getTransactionId() + ":" + item.getType());
					}
				}
			} else {
				System.out.println(item.getTransactionId() + ":" + item.getType());
			}

		});
		return map;
	}

	@Override
	@Transactional(value = "transactionTransactionManager")
	public Map<String, List<Map<String, Object>>> findTransactionById(String id) {
		// TODO Auto-generated method stub
		List<ApiAuditEntity> list = this.apiAuditRepository.findByTransactionIdOrderByCreatedOnAsc(id);
		return getTransationList(list);
	}

	@Override
	public Map<String, List<Map<String, Object>>> findTransactionByDate(String start, String end, Integer page) {
		// TODO Auto-generated method stub
		LocalDateTime startDt = CommonUtl.convertStartStringtoDate(start);
		LocalDateTime endDt = CommonUtl.convertEndStringtoDate(end);
		// Pageable pageable = PageRequest.of(page - 1,
		// Constants.PAGE_SIZE_TRANSACTION);
		List<String> ids = this.apiAuditRepository.findDistinctTransactionIdByCreatedOnBetween(startDt, endDt);// ,pageable
		ids = ids.stream().distinct().collect(Collectors.toList());
		int size = (page) * Constants.PAGE_SIZE_TRANSACTION;
		int startPage = (page - 1) * Constants.PAGE_SIZE_TRANSACTION;
		int endPage = size < ids.size() ? size : ids.size();
		List<String> newIds = ids.subList(startPage, endPage);

		List<ApiAuditEntity> list = this.apiAuditRepository.findByTransactionIdInOrderByCreatedOnAsc(newIds);// ,pageable

		return getTransationList(list);
	}

	@Override
	@Transactional(value = "transactionTransactionManager")
	public List<String> getDistinctId() {
		// TODO Auto-generated method stub
		return this.apiAuditRepository.getDistinctId();
	}

	@Override
	@Transactional(value = "transactionTransactionManager")
	public List<Graph<Integer>> getDashBoard(String type) {
		List<Graph<Integer>> mapAL = new ArrayList<>();
		List<LocalDateTime> al = null;
		if (Constants.dash_type_WEEKS.equals(type)) {
			al = CommonUtl.getLastWeeks(LocalDateTime.now(), Integer.parseInt(this.weeks));
		} else if (Constants.dash_type_MONTHS.equals(type)) {
			al = CommonUtl.getLastMonths(LocalDateTime.now(), Integer.parseInt(this.months));
		} else if (Constants.dash_type_YEARS.equals(type)) {
			al = CommonUtl.getLastYears(LocalDateTime.now(), Integer.parseInt(this.years));
		} else { // days
			al = CommonUtl.getLastDays(LocalDateTime.now(), Integer.parseInt(this.days));
		}
		for (int i = 0; i < al.size(); i += 2) {
			String x = "";
			if (Constants.dash_type_WEEKS.equals(type)) {
				x = String.valueOf((i / 2) + 1);
			} else if (Constants.dash_type_MONTHS.equals(type)) {
				x = al.get(i).getMonth().name();
			} else if (Constants.dash_type_YEARS.equals(type)) {
				x = String.valueOf(al.get(i).getYear());
			} else { // days
				x = String.valueOf(al.get(i).getDayOfMonth());
			}
			mapAL.add(new Graph<>(x, this.apiAuditRepository.countByCreatedOnBetween(al.get(i), al.get(i + 1))));
		}
		return mapAL;
	}

	@Override
	@Transactional(value = "transactionTransactionManager")
	public List<Graph<Integer>> getDashBoard(String select, String type, String start, String end) {
		List<Graph<Integer>> mapAL = new ArrayList<>();
		List<LocalDateTime> al = null;
		LocalDateTime startDt = CommonUtl.convertStartStringtoDate(start);
		LocalDateTime endDt = CommonUtl.convertEndStringtoDate(end);
		startDt = CommonUtl.setSatrtDate(startDt, select, type);
		if (Constants.dash_type_WEEKS.equals(type)) {
			al = CommonUtl.getLastWeeksWithEndDate(startDt, endDt);
		} else if (Constants.dash_type_MONTHS.equals(type)) {
			al = CommonUtl.getLastMonthsWithEndDate(startDt, endDt);
		} else if (Constants.dash_type_YEARS.equals(type)) {
			al = CommonUtl.getLastYearsWithEndDated(startDt, endDt);
		} else { // days
			al = CommonUtl.getLastDays(endDt, Integer.parseInt(this.days));
		}
		Date dt = new Date();
		System.out.println("Start");
		List<ApiAuditEntityProjecttion> list = this.apiAuditRepository.selectByCreatedOnBetween(startDt, endDt);
		System.out.println(list.size());
		System.out.println("time db:" + (new Date().getTime() - dt.getTime()));
		for (int i = 0; i < al.size(); i += 2) {
			Date dt1 = new Date();
			String x = "";
			if (Constants.dash_type_WEEKS.equals(type)) {
				x = String.valueOf((i / 2) + 1);
			} else if (Constants.dash_type_MONTHS.equals(type)) {
				x = al.get(i).getMonth().name();
			} else if (Constants.dash_type_YEARS.equals(type)) {
				x = String.valueOf(al.get(i).getYear());
			} else { // days
				x = String.valueOf(al.get(i).getDayOfMonth());
			}
			Integer cnt = 0;
			// List<ApiAuditEntityProjecttion> remove = new ArrayList();

			for (ApiAuditEntityProjecttion element : list) {
				if (element.getCreatedOn().isAfter(al.get(i)) && element.getCreatedOn().isBefore(al.get(i + 1))) {
					// remove.add(list.get(i));
					cnt++;
				}

			}
//			if (remove.size() > 0) {
//				list.removeAll(remove);
//			}
			mapAL.add(new Graph<>(x, cnt));
			System.out.println("time:" + (new Date().getTime() - dt1.getTime()));

		}

		return mapAL;
	}

	@Override
	@Transactional(value = "lookupTransactionManager")
	public List<Graph<Integer>> getDashBoardLookup(String select, String type, String start, String end) {
		List<Graph<Integer>> mapAL = new ArrayList<>();
		List<OffsetDateTime> al = null;
		LocalDateTime startDt = CommonUtl.convertStartStringtoDate(start);
		LocalDateTime endDt = CommonUtl.convertEndStringtoDate(end);
		startDt = CommonUtl.setSatrtDate(startDt, select, type);
		if (Constants.dash_type_WEEKS.equals(type)) {
			al = CommonUtl.convertOffsetToLocalDateTime(CommonUtl.getLastWeeksWithEndDate(startDt, endDt));
		} else if (Constants.dash_type_MONTHS.equals(type)) {
			al = CommonUtl.convertOffsetToLocalDateTime(CommonUtl.getLastMonthsWithEndDate(startDt, endDt));
		} else if (Constants.dash_type_YEARS.equals(type)) {
			al = CommonUtl.convertOffsetToLocalDateTime(CommonUtl.getLastYearsWithEndDated(startDt, endDt));
		} else { // days
			al = CommonUtl.convertOffsetToLocalDateTime(CommonUtl.getLastDays(endDt, Integer.parseInt(this.days)));
		}
		Date dt = new Date();
		System.out.println("Start");
		List<NPApiLogs> list = this.apiLogsRepository.findByTypeAndCreatedDateBetweenOrderByCreatedDateAsc(
				Constants.type_lookup, CommonUtl.convertOffsetToLocalDateTime(startDt),
				CommonUtl.convertOffsetToLocalDateTime(endDt));
		System.out.println(list.size());
		System.out.println("time db:" + (new Date().getTime() - dt.getTime()));
		for (int i = 0; i < al.size(); i += 2) {
			Date dt1 = new Date();
			String x = "";
			if (Constants.dash_type_WEEKS.equals(type)) {
				x = String.valueOf((i / 2) + 1);
			} else if (Constants.dash_type_MONTHS.equals(type)) {
				x = al.get(i).getMonth().name();
			} else if (Constants.dash_type_YEARS.equals(type)) {
				x = String.valueOf(al.get(i).getYear());
			} else { // days
				x = String.valueOf(al.get(i).getDayOfMonth());
			}
			Integer cnt = 0;
			// List<ApiAuditEntityProjecttion> remove = new ArrayList();

			for (NPApiLogs element : list) {
				if (element.getCreatedDate().isAfter(al.get(i)) && element.getCreatedDate().isBefore(al.get(i + 1))) {
					// remove.add(list.get(i));
					cnt++;
				}

			}
//			if (remove.size() > 0) {
//				list.removeAll(remove);
//			}
			mapAL.add(new Graph<>(x, cnt));
			System.out.println("time:" + (new Date().getTime() - dt1.getTime()));

		}

		return mapAL;
	}

	public Map<String, Integer> getBuyerSellerMap(List<ApiAuditEntity> list, boolean buyer) {
		Map<String, Integer> mapInt = new HashMap<>();
		list.forEach(item -> {
			if (buyer) {
				if (mapInt.get(item.getBuyerId()) == null) {
					mapInt.put(item.getBuyerId(), 0);
				}

				mapInt.put(item.getBuyerId(), mapInt.get(item.getBuyerId()) + 1);

			} else {

				if (mapInt.get(item.getSellerId()) == null) {
					mapInt.put(item.getSellerId(), 0);
				}

				mapInt.put(item.getSellerId(), mapInt.get(item.getSellerId()) + 1);

			}
		});
		return mapInt;

	}

	public List<Map<String, Object>> findByBuyerSellerTransactionByDate(String typeSearch, String typeOnSerarch,
			String start, String end, String type) {
		// TODO Auto-generated method stub

		LocalDateTime startDt = CommonUtl.convertStartStringtoDate(start);
		// startDt= CommonUtl.setSatrtDate(startDt, select, type);
		LocalDateTime endDt = CommonUtl.convertEndStringtoDate(end);

		List<ApiAuditEntity> list = this.apiAuditRepository.findByTypeAndActionAndCreatedOnBetweenOrderByCreatedOnAsc(
				typeSearch, Constants.action_search, startDt, endDt);
		boolean buyer = Constants.REQUEST_BY_BUYER.equals(typeSearch);
		List<Map<String, Object>> mapList = new ArrayList<>();
		Map<String, Integer> mapSearchInt = getBuyerSellerMap(list, buyer);
		list = this.apiAuditRepository.findByTypeAndActionAndCreatedOnBetweenOrderByCreatedOnAsc(typeOnSerarch,
				Constants.action_on_search, startDt, endDt);
		Map<String, Integer> mapOnSearchInt = getBuyerSellerMap(list, buyer);

		mapSearchInt.entrySet().forEach(item -> {
			Map<String, Object> obj = new HashMap<>();
			mapList.add(obj);
			obj.put(Constants.action_search, item.getValue());
			obj.put(Constants.action_on_search,
					mapOnSearchInt.get(item.getKey()) == null ? 0 : mapOnSearchInt.get(item.getKey()));
			obj.put("name", item.getKey());
		});
		return mapList;
	}

	@Override
	@Transactional(value = "transactionTransactionManager")
	public List<Map<String, Object>> findByBuyerSellerTransactionByDate(String type, String start, String end) {
		if (type.equals("buyer")) {
			return this.findByBuyerSellerTransactionByDate(Constants.REQUEST_BY_BUYER, Constants.ACK_TO_BUYER, start,
					end, type);
		} else if (type.equals("seller")) {
			return this.findByBuyerSellerTransactionByDate(Constants.REQUEST_TO_SELLER, Constants.RESPONSE_BY_SELLER,
					start, end, type);

		} else {
			return null;
		}
	}

	// getDashBoard SummaryReportExportToExcel

	@Override
	@Transactional(value = "transactionTransactionManager")
	public FileBo summaryReportExportToExcel(String start, String end) {

		LocalDateTime startDt = CommonUtl.convertStartStringtoDate(start);
		LocalDateTime endDt = CommonUtl.convertEndStringtoDate(end);

		FileBo bo = new FileBo();

		List<ApiAuditEntity> list = this.apiAuditRepository.findByCreatedOnBetweenOrderByCreatedOnAsc(startDt, endDt);

		System.out.println("Excel Rec :" + list.size());
		String fileName = "TransactionSummaryReport" + "-" + start + "_" + end
				+ this.securityUtils.getUserDetails().getId() + ".xlsx";
		try {

			XSSFWorkbook workbook = new XSSFWorkbook();

			XSSFSheet sheet = workbook.createSheet("summaryreport");
			writeHeaderLine(sheet);
			writeDataLines(list, workbook, sheet);

//			FileOutputStream outputStream = new FileOutputStream("TransactionSummaryReport.xlsx");
//			workbook.write(outputStream);
//			workbook.close();

			ByteArrayOutputStream exportFile = new ByteArrayOutputStream();
			workbook.write(exportFile);
			bo.setBlob(Base64.getEncoder().encodeToString(exportFile.toByteArray()));
			bo.setFileName(fileName);
			bo.setFileType(".xlxs");
			exportFile.close();

			// response.setSuccess(true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			// response.setError(e.getMessage());
			// response.setSuccess(false);

		}
		return bo;

	}

	private void writeHeaderLine(XSSFSheet sheet) {

		Row headerRow = sheet.createRow(0);
		Cell headerCell = headerRow.createCell(0);
		headerCell.setCellValue("created_on");
		headerCell = headerRow.createCell(1);
		headerCell.setCellValue("transaction_id");
		headerCell = headerRow.createCell(2);
		headerCell.setCellValue("message_id");
		headerCell = headerRow.createCell(3);
		headerCell.setCellValue("buyer_id");
		headerCell = headerRow.createCell(4);
		headerCell.setCellValue("seller_id");

		headerCell = headerRow.createCell(5);
		headerCell.setCellValue("action");

		headerCell = headerRow.createCell(6);
		headerCell.setCellValue("type");

		headerCell = headerRow.createCell(7);
		headerCell.setCellValue("error");

		headerCell = headerRow.createCell(8);
		headerCell.setCellValue("Header");
	}

	private void writeDataLines(List<ApiAuditEntity> result, XSSFWorkbook workbook, XSSFSheet sheet) {
		int rowCount = 1;
		for (ApiAuditEntity apiAuditEntity : result) {
			Row row = sheet.createRow(rowCount++);
			int columnCount = 0;
			// Cell cell = row.createCell(columnCount++);

//			CellStyle cellStyle = workbook.createCellStyle();
//			CreationHelper creationHelper = workbook.getCreationHelper();
//			cellStyle.setDataFormat(creationHelper.createDataFormat().getFormat("dd-MM-yyyy HH:mm:ss"));
//
//			cell.setCellStyle(cellStyle);

			// cell.setCellStyle(null);
			// LocalDateTime ldt = rs.getTimestamp("created_dt").toLocalDateTime();

			//
			Cell cell = row.createCell(columnCount++);
			cell.setCellValue(CommonUtl.convertDatetoString(apiAuditEntity.getCreatedOn()));

			cell = row.createCell(columnCount++);
			cell.setCellValue(apiAuditEntity.getTransactionId());

			cell = row.createCell(columnCount++);
			cell.setCellValue(apiAuditEntity.getMessageId());

			cell = row.createCell(columnCount++);
			cell.setCellValue(apiAuditEntity.getBuyerId());

			cell = row.createCell(columnCount++);
			cell.setCellValue(apiAuditEntity.getSellerId());

			cell = row.createCell(columnCount++);
			cell.setCellValue(apiAuditEntity.getAction());

			cell = row.createCell(columnCount++);
			cell.setCellValue(apiAuditEntity.getType());

			cell = row.createCell(columnCount++);
			cell.setCellValue(apiAuditEntity.getError());

			cell = row.createCell(columnCount);
			cell.setCellValue(apiAuditEntity.getHeaders());
		}
	}

	@Override
	@Transactional(value = "transactionTransactionManager")
	public List<ApiAuditEntitySellerProjection> getDashBoardSellerAllList(String start, String end) {
		LocalDateTime startDt = CommonUtl.convertStartStringtoDate(start);
		LocalDateTime endDt = CommonUtl.convertEndStringtoDate(end);
		List<ApiAuditEntitySellerProjection> listAll = new ArrayList<>();
		listAll = this.apiAuditRepository.selectBySellerCreatedOnBetween(startDt, endDt);
		listAll.forEach(item -> {
			System.out.println(item.getSellerId() + ":" + item.getCount());
		});
		return listAll;
	}

	@Override
	@Transactional(value = "transactionTransactionManager")
	public List<Graph<Integer>> getDashBoardSellerId(String select, String type, String start, String end) {
		List<Graph<Integer>> mapAL = new ArrayList<>();
		List<LocalDateTime> al = null;
		LocalDateTime startDt = CommonUtl.convertStartStringtoDate(start);
		LocalDateTime endDt = CommonUtl.convertEndStringtoDate(end);
		startDt = CommonUtl.setSatrtDate(startDt, select, type);
		if (Constants.dash_type_WEEKS.equals(type)) {
			al = CommonUtl.getLastWeeksWithEndDate(startDt, endDt);
		} else if (Constants.dash_type_MONTHS.equals(type)) {
			al = CommonUtl.getLastMonthsWithEndDate(startDt, endDt);
		} else if (Constants.dash_type_YEARS.equals(type)) {
			al = CommonUtl.getLastYearsWithEndDated(startDt, endDt);
		} else { // days
			al = CommonUtl.getLastDays(endDt, Integer.parseInt(this.days));
		}
		Date dt = new Date();
		System.out.println("Start");
		// List<ApiAuditEntitySellerBuyerProjecttion> listAll = new
		// ArrayList<ApiAuditEntitySellerBuyerProjecttion>();
		System.out.println("time db:" + (new Date().getTime() - dt.getTime()));
		for (int i = 0; i < al.size(); i += 2) {
			Date dt1 = new Date();
			String x = "";
			if (Constants.dash_type_WEEKS.equals(type)) {
				x = String.valueOf((i / 2) + 1);
			} else if (Constants.dash_type_MONTHS.equals(type)) {
				x = al.get(i).getMonth().name();
			} else if (Constants.dash_type_YEARS.equals(type)) {
				x = String.valueOf(al.get(i).getYear());
			} else { // days
				x = String.valueOf(al.get(i).getDayOfMonth());
			}
			Integer cnt = 0;
			// List<ApiAuditEntityProjecttion> remove = new ArrayList();
			List<ApiAuditEntitySellerProjection> list = this.apiAuditRepository
					.selectBySellerCreatedOnBetween(al.get(i), al.get(i + 1));
			System.out.println(list.size());

			for (ApiAuditEntitySellerProjection element : list) {

				cnt += element.getCount();
				// listAll.add(list.get(j));
			}
//			if (remove.size() > 0) {
//				list.removeAll(remove);
//			}
			mapAL.add(new Graph<>(x, cnt));
			System.out.println("time:" + (new Date().getTime() - dt1.getTime()));

		}

		return mapAL;
	}

	@Override
	@Transactional(value = "transactionTransactionManager")
	public List<ApiAuditEntityBuyerProjection> getDashBoardBuyerAllList(String start, String end) {
		LocalDateTime startDt = CommonUtl.convertStartStringtoDate(start);
		LocalDateTime endDt = CommonUtl.convertEndStringtoDate(end);
		List<ApiAuditEntityBuyerProjection> listAll = new ArrayList<>();
		listAll = this.apiAuditRepository.selectByBuyerCreatedOnBetween(startDt, endDt);

		return listAll;
	}

	@Override
	@Transactional(value = "transactionTransactionManager")
	public List<Graph<Integer>> getDashBoardBuyerId(String select, String type, String start, String end) {
		List<Graph<Integer>> mapAL = new ArrayList<>();
		List<LocalDateTime> al = null;
		LocalDateTime startDt = CommonUtl.convertStartStringtoDate(start);
		LocalDateTime endDt = CommonUtl.convertEndStringtoDate(end);
		startDt = CommonUtl.setSatrtDate(startDt, select, type);
		if (Constants.dash_type_WEEKS.equals(type)) {
			al = CommonUtl.getLastWeeksWithEndDate(startDt, endDt);
		} else if (Constants.dash_type_MONTHS.equals(type)) {
			al = CommonUtl.getLastMonthsWithEndDate(startDt, endDt);
		} else if (Constants.dash_type_YEARS.equals(type)) {
			al = CommonUtl.getLastYearsWithEndDated(startDt, endDt);
		} else { // days
			al = CommonUtl.getLastDays(endDt, Integer.parseInt(this.days));
		}
		Date dt = new Date();
		System.out.println("Start");
		// List<ApiAuditEntitySellerBuyerProjecttion> listAll = new
		// ArrayList<ApiAuditEntitySellerBuyerProjecttion>();
		System.out.println("time db:" + (new Date().getTime() - dt.getTime()));
		for (int i = 0; i < al.size(); i += 2) {
			Date dt1 = new Date();
			String x = "";
			if (Constants.dash_type_WEEKS.equals(type)) {
				x = String.valueOf((i / 2) + 1);
			} else if (Constants.dash_type_MONTHS.equals(type)) {
				x = al.get(i).getMonth().name();
			} else if (Constants.dash_type_YEARS.equals(type)) {
				x = String.valueOf(al.get(i).getYear());
			} else { // days
				x = String.valueOf(al.get(i).getDayOfMonth());
			}
			Integer cnt = 0;
			// List<ApiAuditEntityProjecttion> remove = new ArrayList();
			List<ApiAuditEntityBuyerProjection> list = this.apiAuditRepository.selectByBuyerCreatedOnBetween(al.get(i),
					al.get(i + 1));
			System.out.println(list.size());

			for (ApiAuditEntityBuyerProjection element : list) {

				cnt += element.getCount();
				// listAll.add(list.get(j));
			}
//			if (remove.size() > 0) {
//				list.removeAll(remove);
//			}
			mapAL.add(new Graph<>(x, cnt));
			System.out.println("time:" + (new Date().getTime() - dt1.getTime()));

		}

		return mapAL;
	}

	@Override
	public List<LogsResponse> findLogsBySubscriberId(LogsRequest body) {
		// return this.apiLogsRepository.findLogsBySubscriberId(body.getSubsciberId());

		List<NPApiLogs> listI = this.entityManager
				.createQuery("SELECT p FROM NPApiLogs p ORDER BY p.createdDate", NPApiLogs.class).setMaxResults(500)
				.getResultList();

		List<LogsResponse> list = new ArrayList<>();
		listI.forEach(item -> {
			list.add(new LogsResponse(item));
		});
		return list;
	}

}
