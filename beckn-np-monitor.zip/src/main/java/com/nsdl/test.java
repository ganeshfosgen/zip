package com.nsdl;

import java.time.Clock;
import java.time.Instant;

import ch.qos.logback.core.util.Duration;

public class test {
public static void main(String[] args) {
	Clock clock = Clock.systemUTC();
	Duration clockSkew;
	System.out.println( Instant.now(clock));
}
}
