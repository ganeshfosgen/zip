package com.nsdl.beckn.lm.model.request;

import lombok.Data;

@Data
public class LogsRequest {
	String subsciberId;
}
