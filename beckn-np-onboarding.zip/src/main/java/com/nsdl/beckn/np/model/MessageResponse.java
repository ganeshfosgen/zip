package com.nsdl.beckn.np.model;

import com.nsdl.beckn.np.utl.Constants;

import lombok.Data;

@Data
public class MessageResponse {

	String details;
	
	
}