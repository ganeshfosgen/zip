package com.nsdl.beckn.lm.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nsdl.beckn.lm.model.FileBo;
import com.nsdl.beckn.lm.model.Graph;
import com.nsdl.beckn.lm.model.projection.ApiAuditEntityBuyerProjection;
import com.nsdl.beckn.lm.model.projection.ApiAuditEntitySellerProjection;
import com.nsdl.beckn.lm.model.request.LogsRequest;
import com.nsdl.beckn.lm.model.response.LogsResponse;
import com.nsdl.beckn.lm.model.response.Response;
import com.nsdl.beckn.lm.service.ApiAuditService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/api/audit")
public class ApiAuditController {
	@Autowired
	ApiAuditService apiAuditService;

	@GetMapping("/get/transaction/{id}")
	public ResponseEntity<Response<Map<String, List<Map<String, Object>>>>> findTransationId(@PathVariable String id) {
		return Response.ok(this.apiAuditService.findTransactionById(id));
	}

	@GetMapping("/get/transaction/by/date/{start}/{end}/{page}")
	public ResponseEntity<Response<Map<String, List<Map<String, Object>>>>> findTransationIdByDate(
			@PathVariable String start, @PathVariable String end, @PathVariable Integer page) {

		return Response.ok(this.apiAuditService.findTransactionByDate(start, end, page));
	}

	@GetMapping("/all/transaction")
	public ResponseEntity<Response<List<String>>> distinctTransationIds() {
		return Response.ok(this.apiAuditService.getDistinctId());
	}

	@GetMapping("/dashboard/{select}/{type}/{start}/{end}")
	public ResponseEntity<Response<List<Graph<Integer>>>> getDashBoard(@PathVariable String select,
			@PathVariable String type, @PathVariable String start, @PathVariable String end) {
		return Response.ok(this.apiAuditService.getDashBoard(select, type, start, end));
	}

	@GetMapping("/dashboard/seller/{select}/{type}/{start}/{end}")
	public ResponseEntity<Response<List<Graph<Integer>>>> getDashBoardSeller(@PathVariable String select,
			@PathVariable String type, @PathVariable String start, @PathVariable String end) {
		return Response.ok(this.apiAuditService.getDashBoardSellerId(select, type, start, end));
	}

	@GetMapping("/dashboard/buyer/{select}/{type}/{start}/{end}")
	public ResponseEntity<Response<List<Graph<Integer>>>> getDashBoardBuyer(@PathVariable String select,
			@PathVariable String type, @PathVariable String start, @PathVariable String end) {
		return Response.ok(this.apiAuditService.getDashBoardSellerId(select, type, start, end));
	}

	@GetMapping("/dashboard/grid/buyer/{start}/{end}")
	public ResponseEntity<Response<List<ApiAuditEntityBuyerProjection>>> getDashBoardBuyer(@PathVariable String start,
			@PathVariable String end) {
		return Response.ok(this.apiAuditService.getDashBoardBuyerAllList(start, end));
	}

	@GetMapping("/dashboard/grid/seller/{start}/{end}")
	public ResponseEntity<Response<List<ApiAuditEntitySellerProjection>>> getDashBoardSeller(@PathVariable String start,
			@PathVariable String end) {
		return Response.ok(this.apiAuditService.getDashBoardSellerAllList(start, end));
	}

	@GetMapping("/dashboard/count/{type}/{start}/{end}")
	public ResponseEntity<Response<List<Map<String, Object>>>> getDashBoardBuyerSeller(@PathVariable String type,
			@PathVariable String start, @PathVariable String end) {
		return Response.ok(this.apiAuditService.findByBuyerSellerTransactionByDate(type, start, end));
	}

	@GetMapping("/dashboard/lookup/{select}/{type}/{start}/{end}")
	public ResponseEntity<Response<List<Graph<Integer>>>> getDashBoardLookup(@PathVariable String select,
			@PathVariable String type, @PathVariable String start, @PathVariable String end) {
		return Response.ok(this.apiAuditService.getDashBoardLookup(select, type, start, end));
	}

	// get summary report api
	@GetMapping("/dashboard/summary/report/{start}/{end}")
	public ResponseEntity<Response<FileBo>> getDashBoard(@PathVariable String start, @PathVariable String end) {
		return Response.ok(this.apiAuditService.summaryReportExportToExcel(start, end));
	}

	@PostMapping("/dashboard/logs")
	public ResponseEntity<Response<List<LogsResponse>>> getLogs(@RequestBody LogsRequest body) {
		return Response.ok(this.apiAuditService.findLogsBySubscriberId(body));
	}

}
