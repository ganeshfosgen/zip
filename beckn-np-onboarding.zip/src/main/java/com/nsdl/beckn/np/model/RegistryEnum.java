package com.nsdl.beckn.np.model;

public enum RegistryEnum {
ENCRYPTION,SIGNING
}
