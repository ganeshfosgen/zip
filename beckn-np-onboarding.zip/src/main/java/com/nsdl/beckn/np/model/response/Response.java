package com.nsdl.beckn.np.model.response;

import org.springframework.http.ResponseEntity;

import com.nsdl.beckn.np.service.OnboardingService;
import com.nsdl.beckn.np.utl.Constants;

import lombok.Data;

@Data
public class Response<T> {

	public Response(String status, T message) {
		super();
		this.status = status;
		this.message = message;

	}

	private String status;
	private T message;

	public static <T> ResponseEntity<Response<T>> ok(T message,OnboardingService onboardingService) {
		ResponseEntity res= ResponseEntity.ok(new Response<T>(Constants.RESPONSE_OK, message));
		onboardingService.saveLogsResponse(res);
		return res;
	}

	public static <T> ResponseEntity<Response<T>> error(T message,OnboardingService onboardingService) {
		ResponseEntity res= ResponseEntity.ok(new Response<T>(Constants.RESPONSE_ERROR, message));
		onboardingService.saveLogsResponse(res);
		return res;
	}
	
	

}