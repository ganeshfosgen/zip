package com.nsdl.beckn.np.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nsdl.beckn.np.model.request.ErrorResponse;
import com.nsdl.beckn.np.model.request.RequestOldSearch;
import com.nsdl.beckn.np.model.request.RequestSearch;
import com.nsdl.beckn.np.model.request.RequestText;
import com.nsdl.beckn.np.model.request.SubscribeBody;
import com.nsdl.beckn.np.model.response.ResponsEntityMaster;
import com.nsdl.beckn.np.model.response.ResponsOldEntityMaster;
import com.nsdl.beckn.np.model.response.Response;
import com.nsdl.beckn.np.model.response.ResponseText;
import com.nsdl.beckn.np.service.OnboardingSubscirberService;
import com.nsdl.signing.model.Web;
import com.nsdl.signing.service.CryptoService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class OnboardingSubcriberController {
	@Autowired
	OnboardingSubscirberService onboardingService;

	@Autowired
	CryptoService cryptoService;

	@GetMapping("/hellotest")
	public ResponseEntity<String> hello() {
		return ResponseEntity.ok("Hello");
	}

	@PostMapping("/subscribe")
	public ResponseEntity<ErrorResponse> subscribe(@RequestBody SubscribeBody subscribeBody) {
		ErrorResponse error = this.onboardingService.onSubscribe(subscribeBody);
		Map<String, Object> map = new HashMap<>();
		map.put("Logs", subscribeBody.getMsgError());
		map.put("response", error);
		Response.ok(map, this.onboardingService);
		return ResponseEntity.ok(error);
	}

	@PostMapping("/vlookup")
	public ResponseEntity<List<ResponsEntityMaster>> lookup(@RequestBody RequestSearch reqLookup) {
		List<ResponsEntityMaster> list = this.onboardingService.lookup(reqLookup);
		log.info(reqLookup.getStatusCode() + ":" + reqLookup.getSearchParameters());

		if ("200".equals(reqLookup.getStatusCode())) {
			return Response.ok(list, this.onboardingService);
		} else {
			Map<String, String> map = new HashMap();
			map.put("StatusCode", reqLookup.getStatusCode());
			map.put("Msg", reqLookup.getMsg());

			Response.error(map, this.onboardingService);

			if ("401".equals(reqLookup.getStatusCode())) {
				return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
			} else if ("412".equals(reqLookup.getStatusCode())) {
				// sender subscriber id is not match
				return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED).build();
			} else if ("411".equals(reqLookup.getStatusCode())) {
				// time stamp is invalid
				return ResponseEntity.status(HttpStatus.LENGTH_REQUIRED).build();
			} else if ("416".equals(reqLookup.getStatusCode())) {
				// at least 2 params in search request
				return ResponseEntity.status(HttpStatus.REQUESTED_RANGE_NOT_SATISFIABLE).build();
			} else {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
			}
		}
//		return ResponseEntity.ok(this.onboardingService.lookup(reqLookup));
	}

	@PostMapping("/lookup")
	public ResponseEntity<List<ResponsOldEntityMaster>> lookupOld(@RequestBody RequestOldSearch reqLookup) {
		List<ResponsOldEntityMaster> list = this.onboardingService.lookupOld(reqLookup);
		log.info(reqLookup.getStatusCode() + ":" + reqLookup);

		if ("200".equals(reqLookup.getStatusCode())) {
			return Response.ok(list, this.onboardingService);
		} else {
			Map<String, String> map = new HashMap();
			map.put("StatusCode", reqLookup.getStatusCode());
			map.put("Msg", reqLookup.getMsg());

			Response.error(map, this.onboardingService);

			if ("416".equals(reqLookup.getStatusCode())) {
				// at least 2 params in search request
				return ResponseEntity.status(HttpStatus.REQUESTED_RANGE_NOT_SATISFIABLE).build();
			} else {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
			}
		}
//		return ResponseEntity.ok(this.onboardingService.lookup(reqLookup));
	}

	@PostMapping("/public/keys")
	public ResponseEntity<Map<String, String>> lookupOndcPublicKey() {
		return ResponseEntity.ok(this.onboardingService.getPublicKey());
	}

	@PostMapping("/challenge/encrypt/text")
	public ResponseEntity<ResponseText> encryptText(@RequestBody RequestText request) {
		return ResponseEntity.ok(this.onboardingService.getEncryptText(request));
	}

	@PostMapping("/challenge/decrypt/text")
	public ResponseEntity<ResponseText> decryptText(@RequestBody RequestText request) {
		return ResponseEntity.ok(this.onboardingService.decryptText(request));
	}

	@PostMapping("/ocsp/verify")
	public ResponseEntity<Map<String, String>> verifyText(@RequestBody Web request) {
		Map<String, String> map = new HashMap<>();
		this.cryptoService.checkOCSP(request, map);
		return ResponseEntity.ok(map);
	}

	@PostMapping("/generate/registry/key")
	public ResponseEntity<String> generateKey() {
		return Response.ok(this.onboardingService.initRKey(), this.onboardingService);
	}

}
