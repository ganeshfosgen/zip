package com.nsdl.beckn.np.utl;

import lombok.Data;

public class Constants {

	public static Integer API_VERSION = 1;
	public static String RESPONSE_ERROR = "error";
	public static String RESPONSE_OK = "success";
	public static String OCSP_NOT_VALID = "Not Valid";

	
	public static String[] RESPONSE_ONBORDING_REQUEST_ERROR = new String[] { "101","Server Side Error. Call Helpdesk for details." };

	public static String[] RESPONSE_ONBORDING_REQUEST_OCSP_ERROR = new String[] { "102","OCSP Validation Failed" };
	public static String[] RESPONSE_ONBORDING_REQUEST_OK = new String[] { "200" ,"Success" };

	public static String[] RESPONSE_VERIFY_DOMAIN_ERROR = new String[] { "103","Domain verification is failed" };
	public static String[] RESPONSE_VERIFY_DOMAIN_OK = new String[] { "200","Domain Verified. Please save ackCode(DverifyAckCode) for verification of keys" };

	public static String[] RESPONSE_VERIFYK_SIG_INIT_ERROR = new String[] { "104","Signature verification is failed" };
	public static String[] RESPONSE_VERIFYK_ENCRYPT_INIT_ERROR = new String[] { "105","Encryption verification is failed" };

	
	public static String[] RESPONSE_ONSUBSCRIBE_REQUEST_ERROR = new String[] { "106","previous_req_id is incorrect" };
	public static String[] RESPONSE_ONSUBSCRIBE_SUBSCRIBE_ID_ERROR = new String[] { "107","subscriber_id is incorrect" };
	public static String[] RESPONSE_ONSUBSCRIBE_OK = new String[] { "200","INITIATED" };
	public static String[] RESPONSE_LOOKP_ERROR = new String[] { "108","Provide at least one attribute" };
	public static String[] RESPONSE_VERIFY_ACK_ERROR = new String[] { "109","Ack code  is not associated with confReqID " };
	public static String[] RESPONSE_REQUEST_ID_ERROR = new String[] { "110","Conf ReqID is not found" };
	public static String[] RESPONSE_VERIFYK_REQ_ID_INIT_ERROR = new String[] { "111","Verify Ack Code is invalid" };
	public static String[] RESPONSE_SERVER_ENC_ERROR = new String[] { "112","Server Encryption keys not found" };

	public static String[] RESPONSE_ONBORDING_REQUEST_SubscriberId_ERROR = new String[] { "113","subscriber_id is required" };
	public static String[] RESPONSE_ONBORDING_REQUEST_subscriber_url_ERROR = new String[] { "114","subscriber_url is required" };
	public static String[] RESPONSE_ONBORDING_REQUEST_signing_public_key_ERROR = new String[] { "115","signing_public_key is required" };
	public static String[] RESPONSE_ONBORDING_REQUEST_encr_public_key_ERROR = new String[] { "116","encr_public_key is required" };
	public static String[] RESPONSE_ONBORDING_REQUEST_callback_url_ERROR = new String[] { "117","callback_url is required" };
	public static String[] RESPONSE_ONBORDING_REQUEST_confReqID_ERROR = new String[] { "118","confReqID is required" };

	public static String[] RESPONSE_ONBORDING_REQUEST_VERIFY_confReqID_ERROR = new String[] { "119","confReqID is required" };
	public static String[] RESPONSE_ONBORDING_REQUEST_VERIFY_verReqID_ERROR = new String[] { "124","verReqID is required" };
	public static String[] RESPONSE_ONBORDING_REQUEST_VERIFY_dInitAckCode_ERROR = new String[] { "125","dInitAckCode is required" };

	
	public static String[] RESPONSE_ONBORDING_REQUEST_KINIT_keyVerReqID_ERROR = new String[] { "120","keyVerReqID is required" };
	public static String[] RESPONSE_ONBORDING_REQUEST_KINIT_dVerifyAckCode_ERROR = new String[] { "121","dVerifyAckCode is required" };
	public static String[] RESPONSE_ONBORDING_REQUEST_KINIT_signature_ERROR = new String[] { "122","signature is required" };
	public static String[] RESPONSE_ONBORDING_REQUEST_KINIT_encMessage_ERROR = new String[] { "123","encMessage is required" };
	
	public static String[] RESPONSE_SUBCRIBE_REQUEST_previous_req_id_ERROR = new String[] { "126","previous_req_id is required" };

	public static String[] RESPONSE_SUBCRIBE_REQUEST_signature_ERROR = new String[] { "127","signature is required" };
	public static String[] RESPONSE_SUBCRIBE_REQUEST_reqID_ERROR = new String[] { "128","reqID is required" };
	public static String[] RESPONSE_DATE_ERROR = new String[] { "129","" };


	public static String STATUS_SUBSCRIBED= "SUBSCRIBED";
	
	public static String REDIES_KEY_LOOKUP= "LOOKUP";
	
}
