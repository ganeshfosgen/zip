import { Injectable } from "@angular/core";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";

import { environment } from "environments/environment";
import { User } from "app/auth/models";
import { ResponseRet } from "../model/response.model";
import { catchError, map, retry } from "rxjs/operators";
import { Observable, of, throwError } from "rxjs";

@Injectable({ providedIn: "root" })
export class HttpCommonService {
  /**
   *
   * @param {HttpClient} _http
   */
  constructor(private _http: HttpClient) {}

  handleError(err: HttpErrorResponse): Observable<ResponseRet<any>> {
    console.log(err);
    let ret: ResponseRet<any> = { status: "error", message: [] };
    return of(ret);
  }

  handleEmptyError(err: HttpErrorResponse): Observable<any> {
    console.log(err);
   
    return of([]);
  }
  /**
   * Get all users
   */
  get(url: string): Observable<ResponseRet<any>> {
    return this._http
      .get<ResponseRet<any>>(`${environment.apiUrl}` + url)
      .pipe(
        map((response: ResponseRet<any>) => response),
        catchError((err: HttpErrorResponse) => this.handleError(err))
      );
  }

  getWithoutError(url: string): Observable<any> {
    return this._http
      .get<any>(`${environment.apiUrl}` + url)
      .pipe(
        map((response: ResponseRet<any>) => response.message),
        catchError((err: HttpErrorResponse) => this.handleEmptyError(err))
      );
  }
}
